#!/data/data/com.termux/files/usr/bin/bash
# ===== Gitee 双向同步脚本 =====
# 功能：支持本地->Gitee 和 Gitee->本地 双向强制同步
# 特点：适配 Gitee API、详细中文日志、错误处理
# 最后更新：2025-07-22

# ====================== 配置区 ======================
GITEE_USER="xiaoran67"
ACCESS_TOKEN="f1c2451a7f139023f6fa07ce4553333e"  # 👈 在 https://gitee.com/profile/personal_access_tokens 生成
REPO_NAME="subscribe"
PROJECT_DIR="/storage/emulated/0/.updates/update"  # 本地目录
MAIN_BRANCH="master"  # Gitee 默认分支是 master
LOG_FILE="$PROJECT_DIR/gitee_sync.log"

# ====================== 初始化 ======================
function log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "🚀 Gitee 双向同步脚本启动"
log "→ 平台: Gitee (码云)"
log "→ 用户名: $GITEE_USER"
log "→ 仓库: $REPO_NAME"
log "→ 本地目录: $PROJECT_DIR"
log "→ 分支: $MAIN_BRANCH"
log "----------------------------------------"

# ====================== 主菜单 ======================
echo "请选择同步方向:"
echo "1) 本地 → Gitee (强制推送)"
echo "2) Gitee → 本地 (强制拉取)"
echo "3) 查看同步日志"
echo "4) 退出"
read -p "请输入选项 (1-4): " choice

case $choice in
    1)
        log "用户选择: 本地 → Gitee"
        sync_direction="push"
        ;;
    2)
        log "用户选择: Gitee → 本地"
        sync_direction="pull"
        ;;
    3)
        echo -e "\n📜 同步日志内容:"
        [ -f "$LOG_FILE" ] && cat "$LOG_FILE" || echo "暂无日志"
        exit 0
        ;;
    4)
        log "用户退出脚本"
        exit 0
        ;;
    *)
        echo "无效选项"
        exit 1
        ;;
esac

# ====================== Gitee API 函数 ======================
function validate_gitee_token() {
    log "验证 Gitee 令牌..."
    RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" \
        "https://gitee.com/api/v5/user?access_token=$ACCESS_TOKEN")
        
    if [ "$RESPONSE" = "200" ]; then
        log "✅ 令牌有效 | 用户: $GITEE_USER"
    else
        log "❌ 令牌无效或过期 (HTTP $RESPONSE)"
        log "解决方案:"
        log "1. 访问 https://gitee.com/profile/personal_access_tokens"
        log "2. 生成新令牌（勾选 projects 权限）"
        log "3. 更新脚本中的 ACCESS_TOKEN"
        exit 1
    fi
}

function check_gitee_repo() {
    log "检查 Gitee 仓库状态..."
    REPO_STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
        "https://gitee.com/api/v5/repos/$GITEE_USER/$REPO_NAME?access_token=$ACCESS_TOKEN")
    
    if [ "$REPO_STATUS" = "200" ]; then
        log "✅ 仓库存在 | 准备同步"
    elif [ "$REPO_STATUS" = "404" ]; then
        log "⚠️  仓库不存在，正在创建..."
        curl -s -X POST \
            "https://gitee.com/api/v5/user/repos?access_token=$ACCESS_TOKEN" \
            -d "{\"name\":\"$REPO_NAME\", \"public\":true}" > /dev/null
        sleep 2 # 等待仓库创建
        log "✅ 仓库创建成功: https://gitee.com/$GITEE_USER/$REPO_NAME"
    else
        log "❌ 仓库检查失败 (HTTP $REPO_STATUS)"
        exit 1
    fi
}

# ====================== 本地 → Gitee 同步 ======================
function sync_push_to_gitee() {
    cd "$PROJECT_DIR" || { log "❌ 目录不存在"; exit 1; }
    
    # 1. 清理旧Git记录
    [ -d .git ] && rm -rf .git
    log "清理完成: 移除所有Git历史"
    
    # 2. 初始化新仓库
    git init --initial-branch="$MAIN_BRANCH" > /dev/null || {
        git init
        git checkout -b "$MAIN_BRANCH"
    }
    log "仓库初始化: 分支 $MAIN_BRANCH"
    
    # 3. 强制添加所有文件
    git add -f . > /dev/null 2>&1
    FILE_COUNT=$(git status --short | wc -l)
    log "添加文件: $FILE_COUNT 个文件"
    
    # 4. 提交变更
    git commit -m "☘️ $(date +'%Y-%m-%d %H:%M:%S')" --quiet || {
        log "⚠️  无文件变更，创建空提交"
        git commit --allow-empty -m "空提交"
    }
    
    # 5. 强制推送到 Gitee
    log "正在强制推送到 Gitee..."
    git remote add origin "https://$GITEE_USER:$ACCESS_TOKEN@gitee.com/$GITEE_USER/$REPO_NAME.git"
    
    # 重试机制
    for i in {1..3}; do
        log "尝试 $i/3..."
        if git push --force --set-upstream origin "$MAIN_BRANCH" 2>&1 | tee -a "$LOG_FILE"; then
            log "✅ 推送成功！"
            break
        elif [ $i -eq 3 ]; then
            log "❌ 推送失败！最后错误信息："
            tail -n 5 "$LOG_FILE"
            exit 1
        else
            log "⏳ 10秒后重试..."
            sleep 10
        fi
    done
    
    log "💥 本地 → Gitee 同步完成"
    log "→ 仓库地址: https://gitee.com/$GITEE_USER/$REPO_NAME"
    log "→ 文件数: $FILE_COUNT"
}

# ====================== Gitee → 本地 同步 ======================
function sync_pull_from_gitee() {
    cd "$PROJECT_DIR" || { log "❌ 目录不存在"; exit 1; }
    
    # 1. 备份当前目录
    BACKUP_DIR="$PROJECT_DIR/../backup_$(date +%s)"
    mkdir -p "$BACKUP_DIR"
    cp -r . "$BACKUP_DIR" && log "⚠️  已备份当前目录到: $BACKUP_DIR"
    
    # 2. 清理本地
    rm -rf .git
    rm -rf -- *  # 删除所有文件
    log "清理完成: 移除所有本地文件"
    
    # 3. 克隆 Gitee 仓库
    log "正在从 Gitee 克隆仓库..."
    git clone "https://$GITEE_USER:$ACCESS_TOKEN@gitee.com/$GITEE_USER/$REPO_NAME.git" . --quiet
    
    if [ $? -eq 0 ]; then
        FILE_COUNT=$(find . -type f | wc -l)
        log "✅ 克隆成功"
        log "→ 文件数: $FILE_COUNT"
        log "→ 分支: $MAIN_BRANCH"
    else
        log "❌ 克隆失败！恢复备份..."
        mv "$BACKUP_DIR"/* . 2>/dev/null
        mv "$BACKUP_DIR"/.[^.]* . 2>/dev/null
        log "已恢复备份"
        exit 1
    fi
    
    log "💥 Gitee → 本地 同步完成"
    log "→ 仓库地址: https://gitee.com/$GITEE_USER/$REPO_NAME"
}

# ====================== 主执行流程 ======================
validate_gitee_token
check_gitee_repo

case $sync_direction in
    "push")
        sync_push_to_gitee
        ;;
    "pull")
        sync_pull_from_gitee
        ;;
esac

log "🔄 同步完成！耗时: $SECONDS 秒"
echo -e "\n✅ 操作成功完成！详细信息请查看日志:"
echo "cat $LOG_FILE"