#!/data/data/com.termux/files/usr/bin/bash
# ===== GitHub 双向同步脚本 =====
# 功能：支持强制推送/拉取覆盖，带冲突检测
# 最后更新：2025-07-22

# ====================== 配置区 ======================
ACCESS_TOKEN="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"  # 👈 必须更新！
USERNAME="xiaoran67"
REPO_NAME="update"
PROJECT_DIR="/storage/emulated/0/.updates/update"
MAIN_BRANCH="main"

# ====================== 初始化 ======================
echo "🔄 GitHub 双向同步脚本 [v1.0]"
cd "$PROJECT_DIR" || { echo "❌ 目录不存在"; exit 1; }

# ===== 配置Git =====
git config --global user.email "$USERNAME@users.noreply.github.com"
git config --global user.name "$USERNAME"
git config --global url."https://$ACCESS_TOKEN@github.com/".insteadOf "https://github.com/"

# ====================== 主菜单 ======================
PS3='请选择同步方向: '
options=(
  "本地 → 远程 (强制覆盖远程)"
  "远程 → 本地 (强制覆盖本地)"
  "退出"
)

select opt in "${options[@]}"
do
    case $opt in
        "本地 → 远程 (强制覆盖远程)")
            echo "💥 选择：强制推送本地到远程"
            break
            ;;
        "远程 → 本地 (强制覆盖本地)")
            echo "💥 选择：强制拉取远程到本地"
            break
            ;;
        "退出")
            echo "退出脚本"
            exit 0
            ;;
        *) echo "无效选项 $REPLY";;
    esac
done

# ====================== 核心函数 ======================
function push_force() {
    # 1. 清理并初始化
    [ -d .git ] && rm -rf .git
    git init --initial-branch="$MAIN_BRANCH" > /dev/null || {
        git init
        git checkout -b "$MAIN_BRANCH"
    }
    
    # 2. 添加所有文件
    git add -f . > /dev/null 2>&1
    FILE_COUNT=$(git status --short | wc -l)
    git commit -m "☘️ $(date +'%Y%m%d %H%M%S')" --quiet
    
    # 3. 强制推送
    git remote add origin "https://github.com/$USERNAME/$REPO_NAME.git" > /dev/null
    if git push --force --set-upstream origin "$MAIN_BRANCH" 2>&1 | grep -v 'warning'; then
        echo -e "\n✅ 本地 → 远程 强制推送成功！"
        echo "├ 文件数: $FILE_COUNT"
        echo "└ 分支: $MAIN_BRANCH"
    else
        echo -e "\n❌ 推送失败！请检查网络和令牌"
    fi
}

function pull_force() {
    # 1. 保存重要文件（可选）
    BACKUP_DIR="$PROJECT_DIR/../backup_$(date +%s)"
    mkdir -p "$BACKUP_DIR"
    cp -r . "$BACKUP_DIR" && echo "⚠️  已备份当前目录到: $BACKUP_DIR"
    
    # 2. 清理本地
    rm -rf .git
    rm -rf -- *  # 删除所有文件（保留隐藏文件需谨慎）
    
    # 3. 克隆远程仓库
    if git clone "https://$ACCESS_TOKEN@github.com/$USERNAME/$REPO_NAME.git" . --quiet; then
        echo -e "\n✅ 远程 → 本地 强制拉取成功！"
        echo "├ 分支: $MAIN_BRANCH"
        echo "└ 文件数: $(find . -type f | wc -l)"
    else
        echo -e "\n❌ 克隆失败！请检查："
        echo "1. 仓库是否存在: https://github.com/$USERNAME/$REPO_NAME"
        echo "2. 令牌权限"
        # 恢复备份
        mv "$BACKUP_DIR"/* . 2>/dev/null
        mv "$BACKUP_DIR"/.[^.]* . 2>/dev/null
    fi
}

# ====================== 执行选择 ======================
case $REPLY in
    1) push_force ;;
    2) pull_force ;;
esac

echo "同步完成！"