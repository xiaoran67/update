
#!/data/data/com.termux/files/usr/bin/bash
# ===== 子目录批量强制推送脚本 =====
# 特点：将 /storage/emulated/0/.github- 下每个子目录推送到独立仓库
# 最后更新：2025-08-15

# === 全局配置 ===
PARENT_DIR="/storage/emulated/0/.updates"  # 目标父目录
ACCESS_TOKEN="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"  # 替换为你的token
USERNAME="xiaoran67"  # 替换为你的用户名
MAIN_BRANCH="main"    # 默认分支名

# === 核心函数 ===
force_push_subdir() {
    local SUBDIR="$1"
    local REPO_NAME=$(basename "$SUBDIR")
    local PROJECT_DIR="$SUBDIR"
    
    echo -e "\n\033[1;34m🚀 开始推送 [$REPO_NAME]\033[0m"
    echo "→ 仓库: $USERNAME/$REPO_NAME"
    echo "→ 目录: $PROJECT_DIR"
    echo "----------------------------------------"

    # 1. 进入子目录
    cd "$PROJECT_DIR" || { echo "❌ 目录不存在"; return 1; }
    echo "[1/5] 进入目录: $(pwd)"

    # 2. 清除所有Git痕迹
    [ -d .git ] && rm -rf .git
    find . -name ".git" -exec rm -rf {} + 2>/dev/null
    echo "[2/5] 清理完成: 移除所有Git历史"

    # 3. 初始化新仓库
    git init --initial-branch="$MAIN_BRANCH" > /dev/null 2>&1 || {
        git init && git checkout -b "$MAIN_BRANCH"
    }
    echo "[3/5] 仓库初始化: 分支 $MAIN_BRANCH"

    # 4. 强制添加所有文件
    git add -f . > /dev/null 2>&1
    FILE_COUNT=$(git status -s | wc -l)
    echo "[4/5] 添加文件: $FILE_COUNT 个文件"

    # 5. 强制推送
    echo "[5/5] 正在强制推送..."
    git commit -m "🌴 $(date +'%Y-%m-%d %H:%M:%S')" --quiet
    git remote add origin "https://$ACCESS_TOKEN@github.com/$USERNAME/$REPO_NAME.git" > /dev/null 2>&1

    # 推送尝试（最多3次）
    local SUCCESS=0
    for i in {1..3}; do
        git push --force --set-upstream origin "$MAIN_BRANCH" > push.log 2>&1
        if [ $? -eq 0 ]; then
            SUCCESS=1
            break
        elif grep -q "Repository not found" push.log; then
            echo "⚠️ 自动创建仓库: $REPO_NAME"
            curl -X POST \
                -H "Authorization: token $ACCESS_TOKEN" \
                -H "Accept: application/vnd.github.v3+json" \
                "https://api.github.com/user/repos" \
                -d "{\"name\":\"$REPO_NAME\",\"private\":false}" > /dev/null 2>&1
            sleep 2
        fi
    done

    # 结果反馈
    if [ $SUCCESS -eq 1 ]; then
        echo -e "\033[1;32m✔ 推送成功!\033[0m"
        echo "→ 仓库地址: https://github.com/$USERNAME/$REPO_NAME"
    else
        echo -e "\033[1;31m❌ 推送失败!\033[0m"
        echo "最后错误:"
        tail -n 3 push.log
        echo "解决方案:"
        echo "1. 手动创建空仓库: https://github.com/new?name=$REPO_NAME"
        echo "2. 确认目录名符合规则(仅字母数字-_，无空格)"
    fi
    
    # 清理日志
    rm -f push.log
    echo "========================================"
}

# === 主程序 ===
echo "🔥 开始批量推送子目录"
echo "父目录: $PARENT_DIR"
echo "GitHub账户: $USERNAME"
echo "----------------------------------------"

# 检查父目录是否存在
[ ! -d "$PARENT_DIR" ] && { 
    echo "❌ 错误：父目录不存在"; 
    echo "请检查路径: $PARENT_DIR";
    exit 1;
}

# 遍历所有一级子目录
COUNT=0
for dir in "$PARENT_DIR"/*/; do
    if [ -d "$dir" ]; then
        force_push_subdir "$dir"
        ((COUNT++))
    fi
done

echo -e "\n\033[1;35m批量推送完成!\033[0m"
echo "总计推送: $COUNT 个仓库"
echo "提示：访问 https://github.com/$USERNAME?tab=repositories 查看所有仓库"
