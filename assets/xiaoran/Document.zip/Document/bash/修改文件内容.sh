import os

# 目标路径（Android 存储路径）
TARGET_PATH = "/storage/emulated/0/.subscribe-main/library"
# 要替换的字符串和目标字符串
OLD_STR = "assets/xiaoran/lib"
NEW_STR = "library"
# 目标文件类型
FILE_EXTENSIONS = ('.txt', '.json')

def replace_in_files():
    # 遍历目标路径下的所有文件和子目录
    for root, dirs, files in os.walk(TARGET_PATH):
        for file in files:
            # 检查文件扩展名是否为目标类型
            if file.lower().endswith(FILE_EXTENSIONS):
                file_path = os.path.join(root, file)
                try:
                    # 读取文件内容
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 替换字符串
                    if OLD_STR in content:
                        new_content = content.replace(OLD_STR, NEW_STR)
                        
                        # 写回文件
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(new_content)
                        print(f"已处理文件: {file_path}")
                except Exception as e:
                    print(f"处理文件 {file_path} 时出错: {str(e)}")

if __name__ == "__main__":
    # 检查目标路径是否存在
    if os.path.exists(TARGET_PATH):
        print(f"开始处理路径: {TARGET_PATH}")
        replace_in_files()
        print("处理完成")
    else:
        print(f"错误: 路径 {TARGET_PATH} 不存在")
