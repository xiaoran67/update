#!/data/data/com.termux/files/usr/bin/bash

# 配置参数（保持你的信息）
ACWING_USERNAME="xiaoran67"  
ACWING_PASSWORD="10066717Ac"     
REPO_NAME="source"              
LOCAL_CODE_PATH="/storage/emulated/0/.updates/update"  
BRANCH="main"  

# 检查本地代码目录是否存在
if [ ! -d "$LOCAL_CODE_PATH" ]; then
  echo "错误：本地代码目录 $LOCAL_CODE_PATH 不存在！"
  exit 1
fi

# 进入本地代码目录（不修改本地文件）
cd "$LOCAL_CODE_PATH" || { echo "无法进入目录 $LOCAL_CODE_PATH"; exit 1; }

# 初始化Git仓库（如果未初始化）
if [ ! -d ".git" ]; then
  echo "初始化本地Git仓库（仅为了推送，不修改文件）..."
  git init
  git add .
  git commit -m "☘️ $(date +'%Y-%m-%d %H:%M:%S')"
  git branch -M "$BRANCH"  
else
  # 已有仓库，强制提交所有本地文件（覆盖远程）
  echo "提交本地文件到Git仓库（仅为了推送，不修改文件内容）..."
  git add .
  git commit -m "强制推送本地文件 $(date +'%Y-%m-%d %H:%M:%S')" --allow-empty
fi

# 关联AcWing远程仓库（如果未关联）
REMOTE_URL="https://$ACWING_USERNAME:$ACWING_PASSWORD@git.acwing.com/$ACWING_USERNAME/$REPO_NAME.git"
if ! git remote | grep -q "origin"; then
  echo "关联远程仓库 $REMOTE_URL..."
  git remote add origin "$REMOTE_URL"
else
  echo "更新远程仓库地址为 $REMOTE_URL..."
  git remote set-url origin "$REMOTE_URL"
fi

# 终极暴力推送：只推本地，不管远程状态（确保本地文件覆盖远程）
echo "强制推送本地文件到远程仓库（本地文件不会被修改）..."
git push -u origin "$BRANCH" --force

# 检查推送结果
if [ $? -eq 0 ]; then
  echo "✅ 本地文件已强制推送到远程仓库！本地文件未被修改。"
else
  echo "❌ 推送失败！检查用户名、密码或仓库权限（本地文件安全）。"
  exit 1
fi
