#!/data/data/com.termux/files/usr/bin/bash
# ===== 安全增量同步 library 到 GitHub =====
# 日期：2025-08-05
# 📁 本地路径：/storage/emulated/0/.subscribe-main/library
# ☁️ 远程路径：https://github.com/xiaoran67/update/tree/main/library

ACCESS_TOKEN="orkaTZvar18FH6Qz7s1z"
USERNAME="xiaoran67"
REPO_NAME="update"
MAIN_BRANCH="main"

REPO_DIR="/data/data/com.termux/files/home/tmp_repo_sync"
LOCAL_SUBDIR="/storage/emulated/0/.subscribe-main/library"

# 清理旧临时仓库（如果存在）
rm -rf "$REPO_DIR"
mkdir -p "$REPO_DIR"
cd "$REPO_DIR" || exit 1

# 初始化一个干净的 Git 仓库并拉取远程最新版本（仅一次）
git init -b "$MAIN_BRANCH"
git remote add origin "https://$ACCESS_TOKEN@github.com/$USERNAME/$REPO_NAME.git"
git fetch origin "$MAIN_BRANCH" --depth=1
git reset --hard origin/"$MAIN_BRANCH"

# 将本地 library 内容复制进远程仓库的 library 目录
mkdir -p library
cp -rf "$LOCAL_SUBDIR"/. library/

# 添加更改并提交
git add library/
if git diff --cached --quiet; then
    echo "✅ 没有任何变更可提交"
else
    git commit -m "🔄 $(date +'%F %T')"
    git push origin "$MAIN_BRANCH"
    echo "🚀 已成功推送更新到 https://github.com/$USERNAME/$REPO_NAME/tree/$MAIN_BRANCH/library"
fi

# 可选：清理临时目录
rm -rf "$REPO_DIR"