#!/data/data/com.termux/files/usr/bin/bash
 
===== 终极强制推送脚本（详细日志版）=====
 
特点：完整展示每步操作细节，无视所有规则强制推送整个目录
 
最后更新：2025-07-24
 
====================== 配置区 ======================
 
请根据实际情况修改以下参数
 
ACCESS_TOKEN="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"  # 必须替换为有效令牌（需repo权限）
USERNAME="xiaoran67"                                     # GitHub用户名
REPO_NAME="subscribe"                                    # 目标仓库名称
PROJECT_DIR="/storage/emulated/0/.subscribe-main"        # 本地目录绝对路径
MAIN_BRANCH="main"                                       # 目标分支名称
COMMIT_MESSAGE="☘️ $(date +'%Y-%m-%d %H:%M:%S')"  # 提交信息（含时间戳）
 
====================== 初始化 ======================
 
echo -e "\033[1;34m💥 开始终极强制推送流程\033[0m"
echo "----------------------------------------"
echo "📌 核心参数确认"
echo "→ 目标仓库: USERNAME/REPO_NAME"
echo "→ 本地目录: $PROJECT_DIR"
echo "→ 目标分支: $MAIN_BRANCH"
echo "→ 强制覆盖: 启用（将完全替换远程仓库内容）"
echo "→ 操作时间: $(date +'%Y-%m-%d %H:%M:%S')"
echo "----------------------------------------"
 
===== 1. 进入项目目录 =====
 
echo -e "\n\033[1;33m[1/5] 进入本地项目目录\033[0m"
echo "执行命令: cd "$PROJECT_DIR""
cd "$PROJECT_DIR" || {
echo -e "\033[1;31m❌ 错误：本地目录不存在或无法访问\033[0m"
echo "请检查路径是否正确：$PROJECT_DIR"
exit 1
}
echo "✅ 成功进入目录: $(pwd)"
 
===== 2. 清理旧Git记录 =====
 
echo -e "\n\033[1;33m[2/5] 清理原有Git历史记录\033[0m"
if [ -d .git ]; then
echo "检测到已有.git目录，执行删除: rm -rf .git"
rm -rf .git
if [ $? -eq 0 ]; then
echo "✅ 成功移除旧Git记录（包括所有提交历史、分支配置）"
else
echo -e "\033[1;31m❌ 错误：无法删除.git目录（可能权限不足）\033[0m"
exit 1
fi
else
echo "ℹ️ 未检测到.git目录，无需清理"
fi
 
===== 3. 初始化新Git仓库 =====
 
echo -e "\n\033[1;33m[3/5] 初始化新的Git仓库\033[0m"
echo "执行命令: git init --initial-branch="$MAIN_BRANCH""
git init --initial-branch="$MAIN_BRANCH" > /dev/null 2>&1
 
兼容旧版本Git（不支持--initial-branch参数）
 
if [ $? -ne 0 ]; then
echo "ℹ️ 检测到旧版本Git，使用兼容模式初始化"
echo "执行命令: git init"
git init > /dev/null 2>&1 || {
echo -e "\033[1;31m❌ 错误：Git初始化失败\033[0m"
echo "请检查是否已安装Git（执行git --version验证）"
exit 1
}
echo "执行命令: git checkout -b "$MAIN_BRANCH""
git checkout -b "$MAIN_BRANCH" > /dev/null 2>&1 || {
echo -e "\033[1;31m❌ 错误：创建分支失败\033[0m"
exit 1
}
fi
echo "✅ 仓库初始化完成，当前分支: $MAIN_BRANCH"
 
===== 4. 强制添加所有文件 =====
 
echo -e "\n\033[1;33m[4/5] 强制添加所有文件到暂存区\033[0m"
echo "执行命令: git add -f . （-f参数强制包含所有文件，忽略.gitignore规则）"
git add -f . > /dev/null 2>&1
 
统计添加的文件数量
 
FILE_COUNT=$(git status --short | wc -l)
if [ $FILE_COUNT -eq 0 ]; then
echo -e "\033[1;31m❌ 错误：未检测到可添加的文件\033[0m"
echo "请检查本地目录是否有内容：$PROJECT_DIR"
exit 1
else
echo "✅ 成功添加 $FILE_COUNT 个文件（包括隐藏文件和.gitignore排除的文件）"
fi
 
===== 5. 提交并强制推送 =====
 
echo -e "\n\033[1;33m[5/5] 提交并强制推送至远程仓库\033[0m"
 
提交暂存区文件
 
echo "执行命令: git commit -m "$COMMIT_MESSAGE""
git commit -m "$COMMIT_MESSAGE" > /dev/null 2>&1 || {
echo -e "\033[1;31m❌ 错误：提交文件失败\033[0m"
exit 1
}
echo "✅ 本地提交完成，提交信息：$COMMIT_MESSAGE"
 
配置远程仓库地址（含令牌认证）
 
echo "执行命令: git remote add origin https://[令牌]@github.com/USERNAME/REPO_NAME.git"
git remote add origin "https://ACCESS_TOKEN@github.com/USERNAME/$REPO_NAME.git" > /dev/null 2>&1
 
若远程已存在，强制覆盖配置
 
if [ $? -ne 0 ]; then
echo "ℹ️ 远程仓库origin已存在，执行更新: git remote set-url origin [新地址]"
git remote set-url origin "https://ACCESS_TOKEN@github.com/USERNAME/$REPO_NAME.git" > /dev/null 2>&1
fi
 
强制推送（覆盖远程分支）
 
echo "执行命令: git push --force --set-upstream origin $MAIN_BRANCH"
echo "（--force参数将强制覆盖远程分支，此操作不可逆！）"
PUSH_OUTPUT=(git push --force --set-upstream origin "MAIN_BRANCH" 2>&1)
 
过滤警告信息，保留关键输出
 
echo "$PUSH_OUTPUT" | grep -v 'warning'
 
===== 结果验证 =====
 
if [ $? -eq 0 ]; then
echo -e "\n\033[1;32m🎉 强制推送成功！远程仓库已被完全覆盖\033[0m"
echo "----------------------------------------"
echo "📊 推送结果详情"
echo "→ 仓库地址: https://github.com/USERNAME/REPO_NAME"
echo "→ 目标分支: $MAIN_BRANCH"
echo "→ 提交文件数: $FILE_COUNT 个"
echo "→ 提交时间: $(date +'%Y-%m-%d %H:%M:%S')"
echo "----------------------------------------"
else
echo -e "\n\033[1;31m❌ 推送失败！详细错误信息如下\033[0m"
echo "----------------------------------------"
echo "$PUSH_OUTPUT"  # 显示完整错误信息
echo "----------------------------------------"
echo "🔧 解决方案建议"
echo "1. 检查ACCESS_TOKEN有效性：登录GitHub → Settings → Developer settings → Personal access tokens"
echo "2. 确认令牌权限：必须勾选'repo'权限（允许读写仓库）"
echo "3. 验证仓库存在：https://github.com/USERNAME/REPO_NAME"
echo "4. 网络问题：检查网络连接，确保能访问GitHub"
exit 1
fi
 
echo -e "\n\033[1;34m📝 操作流程结束\033[0m"