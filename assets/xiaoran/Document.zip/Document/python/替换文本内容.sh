#!/data/data/com.termux/files/usr/bin/bash

# 定义文件路径
FILE_PATH="/storage/emulated/0/下载/Document/abner.json"

# 检查文件是否存在
if [ ! -f "$FILE_PATH" ]; then
    echo "错误：文件 $FILE_PATH 不存在！"
    exit 1
fi

# 替换文本（将“abner0006”替换为“xiaoran67”，可修改为你的需求）
sed -i 's/xiaoranmuze/xiaoran67/g' "$FILE_PATH"

# 提示完成
if [ $? -eq 0 ]; then
    echo "替换完成！文件路径：$FILE_PATH"
else
    echo "替换失败，请检查文件权限或内容"
fi
