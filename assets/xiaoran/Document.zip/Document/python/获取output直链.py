owner="xiaoran67"
repo="update"
branch="xiaoran"
dir="output"

# 克隆仓库（如果未克隆）
if [ ! -d "${repo}" ]; then
  git clone --depth 1 --branch ${branch} https://github.com/${owner}/${repo}.git
fi

# 进入仓库目录
cd ${repo}

# 提取 output 目录下的所有 txt 文件路径
files=$(git ls-files ${dir} | grep '\.txt$')

# 拼接直链
raw_base="https://raw.githubusercontent.com/${owner}/${repo}/${branch}"
for file in ${files}; do
  echo "${raw_base}/${file}"
done
