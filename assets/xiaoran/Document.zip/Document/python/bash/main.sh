#!/data/data/com.termux/files/usr/bin/bash
set -e  # 遇到错误立即退出

#######################################
# 📁 核心路径配置（根据需求修改）
#######################################
WORK_DIR="/storage/emulated/0/.subscribe-main"  # 工作目录
OUTPUT_DIR="$WORK_DIR/output"                   # 输出目录
HISTORY_DIR="$WORK_DIR/history"                 # 归档目录

#######################################
# 🔧 1. 强制修复环境
#######################################
echo -e "\n🔧 [1/6] 暴力修复环境中，请稍候..."
export PATH="$HOME/.local/bin:$PATH"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

pip install --user --force-reinstall pipenv
pipenv --rm || true
pipenv --python "$PYTHON_VERSION"
pipenv install pytz

if [ "$OPEN_DRIVER" = "true" ]; then
  echo "🌐 检测到启用浏览器驱动，开始安装..."
  pkg install -y chrome chromedriver
  pipenv install selenium
fi

#######################################
# ⚙️ 2. 配置参数定义
#######################################
RETAIN_DAYS=7
FILES_TO_ARCHIVE=(
  "$OUTPUT_DIR/full.txt"
  "$OUTPUT_DIR/simple.txt"
  "$OUTPUT_DIR/others.txt"
  "$OUTPUT_DIR/sports.html"
  "$OUTPUT_DIR/custom.txt"
)
CRITICAL_FILES=(
  "$OUTPUT_DIR/full.txt"
  "$OUTPUT_DIR/custom.txt"
)
CRITICAL_CONTENT="🌐央视频道,#genre#"
CRITICAL_CONTENT_FILE="$OUTPUT_DIR/custom.txt"

#######################################
# 📂 3. 检查工作目录
#######################################
echo -e "\n📂 [2/6] 检查并准备工作目录..."
if [ ! -d "$WORK_DIR" ]; then
  echo "❌ 错误：工作目录不存在 → $WORK_DIR"
  echo "🛠️ 请手动创建目录后重试"
  exit 1
fi
cd "$WORK_DIR"
mkdir -p "$OUTPUT_DIR" "$HISTORY_DIR"

#######################################
# 🧰 4. 执行主脚本生成文件
#######################################
echo -e "\n🧰 [3/6] 正在运行主脚本生成目标文件..."
if [ ! -f "$WORK_DIR/main.py" ]; then
  echo "❌ 错误：未找到 main.py → $WORK_DIR/main.py"
  exit 1
fi

python "$WORK_DIR/main.py" || {
  echo "⚠️ 首次运行失败，正在重试一次..."
  python "$WORK_DIR/main.py" || {
    echo "❌ 错误：生成失败，终止流程"
    exit 1
  }
}

#######################################
# 🧪 5. 校验输出文件完整性
#######################################
echo -e "\n🧪 [4/6] 校验文件完整性..."
for file in "${CRITICAL_FILES[@]}"; do
  if [ ! -s "$file" ]; then
    echo "❌ 错误：文件为空或不存在 → $file"
    exit 1
  fi
done

if ! grep -q "$CRITICAL_CONTENT" "$CRITICAL_CONTENT_FILE"; then
  echo "❌ 错误：关键内容缺失 → $CRITICAL_CONTENT_FILE"
  exit 1
fi

#######################################
# 📦 6. 管理历史归档文件
#######################################
echo -e "\n📦 [5/6] 检查并处理历史归档..."
find "$HISTORY_DIR" -name "*.zip" -type f -mtime +$RETAIN_DAYS -delete || {
  echo "⚠️ 无法删除旧归档，但流程继续"
}

latest_archive=$(ls -t "$HISTORY_DIR"/*.zip 2>/dev/null | head -n 1)
need_archive=0

if [ -z "$latest_archive" ]; then
  need_archive=1
else
  temp_dir=$(mktemp -d)
  unzip -q -o "$latest_archive" -d "$temp_dir"

  for file in "${FILES_TO_ARCHIVE[@]}"; do
    filename=$(basename "$file")
    if ! diff -q "$file" "$temp_dir/$filename" &> /dev/null; then
      need_archive=1
      break
    fi
  done
  rm -rf "$temp_dir"
fi

if [ $need_archive -eq 1 ]; then
  current_datetime=$(date +"%Y%m%d_%H%M%S")
  zip_filename="$HISTORY_DIR/${current_datetime}_archive.zip"
  zip -j "$zip_filename" "${FILES_TO_ARCHIVE[@]}"
  echo "✅ 已生成新归档：$zip_filename"
else
  echo "ℹ️ 未检测到文件变化，跳过归档"
fi

#######################################
# 🎉 完成提示
#######################################
echo -e "\n🎉 [6/6] 所有任务执行完成！"
echo "📁 输出目录：$OUTPUT_DIR"
echo "🗂️ 历史归档：$HISTORY_DIR"
echo "🚀 已准备好进行下一步操作"