#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v3.00 ======
# ======= LiveSource-Collector =======
# ===========  重构版============

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re  # 正则
import os
from datetime import datetime, timedelta, timezone
import random
import opencc  # 简繁转换
import socket
import time

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)  # 创建输出目录，如果已存在则不会报错
print("📁 创建输出目录: output")

# ========= 频道分类配置 =========
# 保持与v2.00完全相同的结构和顺序
CHANNEL_CATEGORIES = {
    "yangshi": {"lines": [], "title": "🌐央视频道", "dict_file": "主频道/CCTV.txt"},
    "weishi": {"lines": [], "title": "📡卫视频道", "dict_file": "主频道/卫视.txt"},
    
    "beijing": {"lines": [], "title": "🏛️北京频道", "dict_file": "地方台/北京.txt"},
    "shanghai": {"lines": [], "title": "🏙️上海频道", "dict_file": "地方台/上海.txt"},
    "guangdong": {"lines": [], "title": "🦁广东频道", "dict_file": "地方台/广东.txt"},
    "jiangsu": {"lines": [], "title": "🍃江苏频道", "dict_file": "地方台/江苏.txt"},
    "zhejiang": {"lines": [], "title": "🧵浙江频道", "dict_file": "地方台/浙江.txt"},
    "shandong": {"lines": [], "title": "⛰️山东频道", "dict_file": "地方台/山东.txt"},
    "sichuan": {"lines": [], "title": "🐼四川频道", "dict_file": "地方台/四川.txt"},
    "henan": {"lines": [], "title": "⚔️河南频道", "dict_file": "地方台/河南.txt"},
    "hunan": {"lines": [], "title": "🌶️湖南频道", "dict_file": "地方台/湖南.txt"},
    "chongqing": {"lines": [], "title": "🍲重庆频道", "dict_file": "地方台/重庆.txt"},
    "tianjin": {"lines": [], "title": "🚢天津频道", "dict_file": "地方台/天津.txt"},
    "hubei": {"lines": [], "title": "🌉湖北频道", "dict_file": "地方台/湖北.txt"},
    "anhui": {"lines": [], "title": "🌾安徽频道", "dict_file": "地方台/安徽.txt"},
    "fujian": {"lines": [], "title": "🌊福建频道", "dict_file": "地方台/福建.txt"},
    "liaoning": {"lines": [], "title": "🏭辽宁频道", "dict_file": "地方台/辽宁.txt"},
    "shaanxi": {"lines": [], "title": "🗿陕西频道", "dict_file": "地方台/陕西.txt"},
    "hebei": {"lines": [], "title": "⛩️河北频道", "dict_file": "地方台/河北.txt"},
    "jiangxi": {"lines": [], "title": "🍶江西频道", "dict_file": "地方台/江西.txt"},
    "guangxi": {"lines": [], "title": "💃广西频道", "dict_file": "地方台/广西.txt"},
    "yunnan": {"lines": [], "title": "☁️云南频道", "dict_file": "地方台/云南.txt"},
    "shanxi": {"lines": [], "title": "🏮山西频道", "dict_file": "地方台/山西.txt"},
    "heilongjiang": {"lines": [], "title": "❄️黑·龙·江", "dict_file": "地方台/黑龙江.txt"},
    "jilin": {"lines": [], "title": "🎎吉林频道", "dict_file": "地方台/吉林.txt"},
    "guizhou": {"lines": [], "title": "🌈贵州频道", "dict_file": "地方台/贵州.txt"},
    "gansu": {"lines": [], "title": "🐫甘肃频道", "dict_file": "地方台/甘肃.txt"},
    "neimenggu": {"lines": [], "title": "🐎内·蒙·古", "dict_file": "地方台/内蒙.txt"},
    "xinjiang": {"lines": [], "title": "🍇新疆频道", "dict_file": "地方台/新疆.txt"},
    "hainan": {"lines": [], "title": "🏝️海南频道", "dict_file": "地方台/海南.txt"},
    "ningxia": {"lines": [], "title": "🕌宁夏频道", "dict_file": "地方台/宁夏.txt"},
    "qinghai": {"lines": [], "title": "🐑青海频道", "dict_file": "地方台/青海.txt"},
    "xizang": {"lines": [], "title": "🐐西藏频道", "dict_file": "地方台/西藏.txt"},
    
    "hongkong": {"lines": [], "title": "🇭🇰香港频道", "dict_file": "地方台/香港.txt"},
    "macau": {"lines": [], "title": "🇲🇴澳门频道", "dict_file": "地方台/澳门.txt"},
    "taiwan": {"lines": [], "title": "🇨🇳台湾频道", "dict_file": "地方台/台湾.txt"},
    
    "digital": {"lines": [], "title": "📶数字频道", "dict_file": "主频道/数字.txt"},
    "movie": {"lines": [], "title": "🎬电影频道", "dict_file": "主频道/电影.txt"},
    "tv_drama": {"lines": [], "title": "📺电·视·剧", "dict_file": "主频道/电视剧.txt"},
    "documentary": {"lines": [], "title": "📽️纪·录·片", "dict_file": "主频道/纪录片.txt"},
    "cartoon": {"lines": [], "title": "🦊动·画·片", "dict_file": "主频道/动画片.txt"},
    "radio": {"lines": [], "title": "📻收·音·机", "dict_file": "主频道/收音机.txt"},
    "variety": {"lines": [], "title": "🎭综艺频道", "dict_file": "主频道/综艺.txt"},
    "huya": {"lines": [], "title": "🐯虎牙直播", "dict_file": "主频道/虎牙.txt"},
    "douyu": {"lines": [], "title": "🐠斗鱼直播", "dict_file": "主频道/斗鱼.txt"},
    "commentary": {"lines": [], "title": "🎤解说频道", "dict_file": "主频道/解说.txt"},
    "music": {"lines": [], "title": "🎵音乐频道", "dict_file": "主频道/音乐.txt"},
    "food": {"lines": [], "title": "🍜美食频道", "dict_file": "主频道/美食.txt"},
    "travel": {"lines": [], "title": "✈️旅游频道", "dict_file": "主频道/旅游.txt"},
    "health": {"lines": [], "title": "🏥健康频道", "dict_file": "主频道/健康.txt"},
    "finance": {"lines": [], "title": "💰财经频道", "dict_file": "主频道/财经.txt"},
    "shopping": {"lines": [], "title": "🛍️购物频道", "dict_file": "主频道/购物.txt"},
    "game": {"lines": [], "title": "🎮游戏频道", "dict_file": "主频道/游戏.txt"},
    "news": {"lines": [], "title": "📰新闻频道", "dict_file": "主频道/新闻.txt"},
    "china": {"lines": [], "title": "🇨🇳中国综合", "dict_file": "主频道/中国.txt"},
    "international": {"lines": [], "title": "🌐国际频道", "dict_file": "主频道/国际.txt"},
    "sports": {"lines": [], "title": "⚽️体育频道", "dict_file": "主频道/体育.txt"},
    "tyss": {"lines": [], "title": "🏆️体育赛事", "dict_file": "主频道/体育赛事.txt"},
    "mgss": {"lines": [], "title": "🏈咪咕赛事", "dict_file": "主频道/咪咕赛事.txt"},
    "traditional_opera": {"lines": [], "title": "🎭戏曲频道", "dict_file": "主频道/戏曲.txt"},
    "spring_festival_gala": {"lines": [], "title": "🧨历届春晚", "dict_file": "主频道/春晚.txt"},
    "camera": {"lines": [], "title": "🏞️景区直播", "dict_file": "主频道/直播中国.txt"},
    "favorite": {"lines": [], "title": "⭐收藏频道", "dict_file": "主频道/收藏频道.txt"},
}

# ========= 全局变量 =========
processed_urls = set()  # 全局URL去重集合
combined_blacklist = set()  # 合并黑名单
corrections_name = {}  # 频道名称纠错字典
dictionaries = {}  # 频道字典
other_lines = []  # 其他未分类频道

# ========= 工具函数 =========
def traditional_to_simplified(text: str) -> str:
    """繁体转简体"""
    converter = opencc.OpenCC('t2s')
    return converter.convert(text)

def get_beijing_time():
    """获取北京时间"""
    utc_now = datetime.now(timezone.utc)
    return utc_now + timedelta(hours=8)

def read_txt_to_array(file_name):
    """读取文本文件内容到数组"""
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            return lines
    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_name}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_name}: {e}")
        return []

def get_random_user_agent():
    """获取随机User-Agent"""
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def clean_url(url):
    """清理URL（移除$后的参数）"""
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

def get_url_file_extension(url):
    """获取URL文件扩展名"""
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

def convert_m3u_to_txt(m3u_content):
    """将M3U格式转换为TXT格式"""
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

def process_name_string(input_str):
    """处理频道名称字符串（主要用于处理CCTV频道名）"""
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

def process_part(part_str):
    """处理单个频道名称部分"""
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "")
        part_str = part_str.replace("PLUS", "+")
        part_str = part_str.replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV" + filtered_str 
    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    return part_str

# ========= 频道名称清理 =========
REMOVAL_LIST = [
    "_电信", "电信", "频道", "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆", "伍陆",
    "陆陆", "柒陆", "肆柒", "频英", "频特", "频国", "频晴", "频粤", "高清", "超清",
    "标清", "斯特", "粤陆", "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特",
    "高特", "频高", "频标", "汝阳", "频效", "国标", "粤标", "频推", "频流", "粤高",
    "频限", "实时", "美推", "频美", "英陆", "(北美)", "「回看」", "[超清]", "「IPV4」",
    "「IPV6」", "_ITV", "(HK)", "AKtv", "HD", "[HD]", "(HD)", "（HD）", "{HD}", "<HD>",
    "-HD", "[BD]", "SD", "[SD]", "(SD)", "{SD}", "<SD>", "[VGA]", "4Gtv", "1080",
    "720", "480", "VGA", "4K", "(4K)", "{4K}", "<4K>", "(VGA)", "{VGA}", "<VGA>",
    "「4gTV」", "「LiTV」"
]

def clean_channel_name(channel_name, removal_list=REMOVAL_LIST):
    """清理频道名称"""
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]

    return channel_name

def correct_name_data(corrections, data):
    """修正频道名称数据"""
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

# ========= 从字符串中提取数字的函数（用于排序） =========
def extract_number(s):
    """从频道名称中提取数字用于排序（与v2.00完全一致）"""
    try:
        num_str = s.split(',')[0].split('-')[1]
        numbers = re.findall(r'\d+', num_str)
        return int(numbers[-1]) if numbers else 999
    except (IndexError, ValueError):
        return 999

# ========= 自定义排序函数（优先4K、8K频道）=========
def custom_sort(s):
    """自定义排序函数（与v2.00完全一致）"""
    try:
        if "CCTV-4K" in s:
            return 2
        elif "CCTV-8K" in s:
            return 3
        elif "(4K)" in s:
            return 1
        else:
            return 0
    except:
        return 0

def sort_data(order, data):
    """按指定顺序排序数据"""
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# ========= 字典文件加载 =========
def load_dictionaries():
    """加载所有频道字典（与v2.00完全一致）"""
    print("📚 加载频道字典...")
    
    # 按v2.00的顺序加载字典
    dict_files = [
        ("yangshi", "主频道/CCTV.txt"),
        ("weishi", "主频道/卫视.txt"),
        ("beijing", "地方台/北京.txt"),
        ("shanghai", "地方台/上海.txt"),
        ("guangdong", "地方台/广东.txt"),
        ("jiangsu", "地方台/江苏.txt"),
        ("zhejiang", "地方台/浙江.txt"),
        ("shandong", "地方台/山东.txt"),
        ("sichuan", "地方台/四川.txt"),
        ("henan", "地方台/河南.txt"),
        ("hunan", "地方台/湖南.txt"),
        ("chongqing", "地方台/重庆.txt"),
        ("tianjin", "地方台/天津.txt"),
        ("hubei", "地方台/湖北.txt"),
        ("anhui", "地方台/安徽.txt"),
        ("fujian", "地方台/福建.txt"),
        ("liaoning", "地方台/辽宁.txt"),
        ("shaanxi", "地方台/陕西.txt"),
        ("hebei", "地方台/河北.txt"),
        ("jiangxi", "地方台/江西.txt"),
        ("guangxi", "地方台/广西.txt"),
        ("yunnan", "地方台/云南.txt"),
        ("shanxi", "地方台/山西.txt"),
        ("heilongjiang", "地方台/黑龙江.txt"),
        ("jilin", "地方台/吉林.txt"),
        ("guizhou", "地方台/贵州.txt"),
        ("gansu", "地方台/甘肃.txt"),
        ("neimenggu", "地方台/内蒙.txt"),
        ("xinjiang", "地方台/新疆.txt"),
        ("hainan", "地方台/海南.txt"),
        ("ningxia", "地方台/宁夏.txt"),
        ("qinghai", "地方台/青海.txt"),
        ("xizang", "地方台/西藏.txt"),
        ("hongkong", "地方台/香港.txt"),
        ("macau", "地方台/澳门.txt"),
        ("taiwan", "地方台/台湾.txt"),
        ("digital", "主频道/数字.txt"),
        ("movie", "主频道/电影.txt"),
        ("tv_drama", "主频道/电视剧.txt"),
        ("documentary", "主频道/纪录片.txt"),
        ("cartoon", "主频道/动画片.txt"),
        ("radio", "主频道/收音机.txt"),
        ("variety", "主频道/综艺.txt"),
        ("huya", "主频道/虎牙.txt"),
        ("douyu", "主频道/斗鱼.txt"),
        ("commentary", "主频道/解说.txt"),
        ("music", "主频道/音乐.txt"),
        ("food", "主频道/美食.txt"),
        ("travel", "主频道/旅游.txt"),
        ("health", "主频道/健康.txt"),
        ("finance", "主频道/财经.txt"),
        ("shopping", "主频道/购物.txt"),
        ("game", "主频道/游戏.txt"),
        ("news", "主频道/新闻.txt"),
        ("china", "主频道/中国.txt"),
        ("international", "主频道/国际.txt"),
        ("sports", "主频道/体育.txt"),
        ("tyss", "主频道/体育赛事.txt"),
        ("mgss", "主频道/咪咕赛事.txt"),
        ("traditional_opera", "主频道/戏曲.txt"),
        ("spring_festival_gala", "主频道/春晚.txt"),
        ("camera", "主频道/直播中国.txt"),
        ("favorite", "主频道/收藏频道.txt"),
    ]
    
    for category_id, dict_file in dict_files:
        dict_path = f"assets/livesource/{dict_file}"
        if os.path.exists(dict_path):
            dictionaries[category_id] = read_txt_to_array(dict_path)
        else:
            dictionaries[category_id] = []
            print(f"   ⚠️  {dict_path}: 文件不存在")
    
    print(f"✅ 字典加载完成，共 {len(dictionaries)} 个分类")

def load_corrections_name():
    """加载频道名称修正字典"""
    filename = 'assets/livesource/corrections_name.txt'
    corrections = {}
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # 跳过空行和注释行
                if not line or line.startswith('#'):
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
    except FileNotFoundError:
        print(f"⚠️  修正字典文件未找到: {filename}")
    except Exception as e:
        print(f"❌ 加载修正字典错误: {e}")
    
    return corrections

def load_blacklist():
    """加载黑名单"""
    print("🚫 加载黑名单...")
    
    def read_blacklist_from_txt(file_path):
        blacklist = set()
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
            for line in lines:
                if ',' in line:
                    url = line.split(',')[1].strip()
                    cleaned_url = clean_url(url)
                    blacklist.add(cleaned_url)
        except Exception as e:
            print(f"❌ 读取黑名单错误 {file_path}: {e}")
        return blacklist
    
    blacklist_auto = read_blacklist_from_txt('assets/livesource/blacklist/blacklist_auto.txt') 
    blacklist_manual = read_blacklist_from_txt('assets/livesource/blacklist/blacklist_manual.txt') 
    
    combined_blacklist = set(blacklist_auto.union(blacklist_manual))
    
    return combined_blacklist

# ========= 核心处理函数 =========
def process_channel_line(line):
    """处理单行频道信息（与v2.00逻辑完全一致）"""
    # 检查是否为有效的频道行
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        # 分割行，获取原始频道名称和URL
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        # 清理URL
        channel_address = clean_url(channel_address)
        
        # 黑名单检查
        if channel_address in combined_blacklist:
            print(f"🚫 黑名单过滤: {channel_name}")
            return
        
        # 全局URL去重检查
        if channel_address in processed_urls:
            print(f"🔄 URL去重: {channel_name}")
            return
        
        processed_urls.add(channel_address)
        
        # 清理频道名称
        channel_name = clean_channel_name(channel_name)
        # 繁体转简体
        channel_name = traditional_to_simplified(channel_name)
        
        # 频道名称纠错
        if channel_name in corrections_name:
            corrected_name = corrections_name[channel_name]
            if corrected_name != channel_name:
                print(f"🔧 名称纠错: {channel_name} -> {corrected_name}")
                channel_name = corrected_name
        
        # 重新组合行
        line = channel_name + "," + channel_address
        
        # 按v2.00的分发顺序处理
        processed_line = process_name_string(line.strip())
        
        # 央视（CCTV关键词匹配） - v2.00逻辑
        if "CCTV" in channel_name:
            CHANNEL_CATEGORIES["yangshi"]["lines"].append(processed_line)
            return
        
        # 卫视（精确匹配）
        if channel_name in dictionaries.get("weishi", []):
            CHANNEL_CATEGORIES["weishi"]["lines"].append(processed_line)
            return
        
        # 体育赛事（关键词匹配）- v2.00逻辑
        if any(tyss_keyword in channel_name for tyss_keyword in dictionaries.get("tyss", [])):
            CHANNEL_CATEGORIES["tyss"]["lines"].append(processed_line)
            return
        
        # 咪咕赛事（关键词匹配）- v2.00逻辑
        if any(mgss_keyword in channel_name for mgss_keyword in dictionaries.get("mgss", [])):
            CHANNEL_CATEGORIES["mgss"]["lines"].append(processed_line)
            return
        
        # 地方台（按v2.00顺序）
        for category_id in ["beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
                           "shandong", "sichuan", "henan", "hunan", "chongqing",
                           "tianjin", "hubei", "anhui", "fujian", "liaoning", "shaanxi",
                           "hebei", "jiangxi", "guangxi", "yunnan", "shanxi", "heilongjiang",
                           "jilin", "guizhou", "gansu", "neimenggu", "xinjiang", "hainan",
                           "ningxia", "qinghai", "xizang"]:
            if channel_name in dictionaries.get(category_id, []):
                CHANNEL_CATEGORIES[category_id]["lines"].append(processed_line)
                return
        
        # 港澳台
        for category_id in ["hongkong", "macau", "taiwan"]:
            if channel_name in dictionaries.get(category_id, []):
                CHANNEL_CATEGORIES[category_id]["lines"].append(processed_line)
                return
        
        # 其他分类（按v2.00顺序）
        for category_id in ["digital", "movie", "tv_drama", "documentary", "cartoon", "radio",
                           "variety", "huya", "douyu", "commentary", "music", "food", "travel",
                           "health", "finance", "shopping", "game", "news", "china", "international",
                           "sports", "traditional_opera", "spring_festival_gala", "camera", "favorite"]:
            if channel_name in dictionaries.get(category_id, []):
                CHANNEL_CATEGORIES[category_id]["lines"].append(processed_line)
                return
        
        # 未匹配到任何分类，放入other_lines（v2.00逻辑：直接添加，不去重）
        other_lines.append(line.strip())

def process_url(url):
    """处理单个URL（与v2.00逻辑完全一致）"""
    try:
        other_lines.append("◆◆◆　" + url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()
            
            # 判断是否为M3U格式
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url) in [".m3u", ".m3u8"] or is_m3u:
                text = convert_m3u_to_txt(text)

            lines = text.split('\n')
            print(f"   行数: {len(lines)}")

            for line in lines:
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    channel_name, channel_address = line.split(',', 1)
                    if "#" not in channel_address:
                        process_channel_line(line)
                    else:
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline = f'{channel_name},{channel_url}'
                            process_channel_line(newline)

            other_lines.append('\n')

    except Exception as e:
        print(f"❌ 处理URL时发生错误：{e}")

# ========= 白名单处理 =========
def process_whitelist():
    """处理白名单自动文件（与v2.00逻辑完全一致）"""
    print("🟢 处理白名单自动文件...")
    whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
    
    for i, whitelist_line in enumerate(whitelist_auto_lines):
        if i < 2:  # 跳过前两行（标题和日期行）
            continue
        
        # 跳过表头行
        if whitelist_line.startswith("RespoTime,whitelist,#genre#"):
            continue
            
        # 处理真正的白名单行
        if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
            whitelist_parts = whitelist_line.split(",")
            if len(whitelist_parts) >= 3:
                try:
                    response_time = float(whitelist_parts[0].replace("ms", ""))
                except ValueError:
                    response_time = 60000
                
                # 只处理响应时间小于2秒的高质量源
                if response_time < 2000:
                    process_channel_line(",".join(whitelist_parts[1:]))

# ========= AKTV特殊处理 =========
def get_http_response(url, timeout=8, retries=2):
    """获取HTTP响应（带重试机制）"""
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(1.0 * (2 ** attempt))
            else:
                print(f"   ❌ HTTP请求失败: {e}")
    return None

def process_aktv():
    """处理AKTV直播源（与v2.00逻辑完全一致）"""
    print("📺 获取AKTV直播源...")
    
    aktv_url = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    
    aktv_text = get_http_response(aktv_url)
    aktv_lines = []
    
    if aktv_text:
        aktv_text = convert_m3u_to_txt(aktv_text)
        aktv_lines = aktv_text.strip().split('\n')
    else:
        aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')
    
    for line in aktv_lines:
        process_channel_line(line)

# ========= 手工区处理 =========
def process_manual_sources():
    """处理手工区高质量源（与v2.00逻辑完全一致）"""
    print("🔧 处理手工区高质量源...")
    
    # 读取手工区文件（与v2.00保持一致）
    zhejiang_manual = read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
    guangdong_manual = read_txt_to_array('assets/livesource/手工区/广东频道.txt')
    hubei_manual = read_txt_to_array('assets/livesource/手工区/湖北频道.txt')
    shanghai_manual = read_txt_to_array('assets/livesource/手工区/上海频道.txt')
    jiangsu_manual = read_txt_to_array('assets/livesource/手工区/江苏频道.txt')
    
    # 添加到对应的频道列表（与v2.00保持一致）
    CHANNEL_CATEGORIES["zhejiang"]["lines"] += zhejiang_manual
    CHANNEL_CATEGORIES["guangdong"]["lines"] += guangdong_manual
    CHANNEL_CATEGORIES["hubei"]["lines"] += hubei_manual
    CHANNEL_CATEGORIES["shanghai"]["lines"] += shanghai_manual
    CHANNEL_CATEGORIES["jiangsu"]["lines"] += jiangsu_manual

# ========= 体育赛事处理 =========
def normalize_date_to_md(text):
    """将日期格式规范化为MM-DD格式（与v2.00逻辑完全一致）"""
    text = text.strip()
    
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

def filter_lines(lines, exclude_keywords):
    """过滤包含特定关键词的行"""
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

def custom_tyss_sort(lines):
    """自定义体育赛事排序函数（数字前缀的倒序，其他正序）"""
    digit_prefix = []
    others = []
    
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

def generate_playlist_html(data_list, output_file='output/tiyu.html'):
    """生成体育赛事HTML页面（与v2.00逻辑完全一致）"""
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''
    
    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''
    
    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 体育赛事网页已生成：{output_file}")

def process_tyss_data():
    """处理体育赛事数据（与v2.00逻辑完全一致）"""
    print("🏆 处理体育赛事数据...")
    
    tyss_lines = CHANNEL_CATEGORIES["tyss"]["lines"]
    
    if not tyss_lines:
        print("⚠️  没有找到体育赛事数据")
        return None
    
    # 日期格式化
    normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]
    
    # 过滤关键词
    keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
    keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]
    
    # 应用过滤
    normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
    
    # 去重并排序
    normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
    
    # 进一步过滤
    filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)
    
    # 生成HTML文件
    generate_playlist_html(filtered_tyss_lines, 'output/tiyu.html')
    
    # 生成TXT文件
    with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
        for line in filtered_tyss_lines:
            f.write(line + '\n')
    
    return filtered_tyss_lines

# ========= 今日推荐和版本信息 =========
def get_random_url(file_path):
    """从文件中随机获取URL（与v2.00逻辑完全一致）"""
    urls = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if ',' in line:
                    url = line.strip().split(',')[-1]
                    urls.append(url)
    except Exception as e:
        print(f"❌ 读取随机URL文件错误 {file_path}: {e}")
    return random.choice(urls) if urls else ""

# ========= 生成输出文件 =========
def generate_output_files(filtered_tyss_lines=None):
    """根据配置生成输出文件（输出与v2.00完全一致）"""
    print("\n📝 生成输出文件...")
    
    # 生成今日推荐和版本信息（与v2.00保持一致）
    beijing_time = get_beijing_time()
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    # 今日推荐
    MTV1 = "💯推荐," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV2 = "🤫低调," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV3 = "🟢使用," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV4 = "⚠️禁止," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV5 = "🚫贩卖," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    
    # 版本信息
    version = formatted_time + "," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    about = "👨潇然," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    
    # 读取手工区文件（与v2.00保持一致）
    zhuanxiang_yangshi = read_txt_to_array('assets/livesource/手工区/优质央视.txt')
    zhuanxiang_weishi = read_txt_to_array('assets/livesource/手工区/优质卫视.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    # ========= 构建完整版播放列表（与v2.00完全一致）=========
    print("✅ 构建完整版播放列表...")
    all_lines_full = []
    
    # 央视频道 - 使用v2.00的特殊排序
    yangshi_lines = correct_name_data(corrections_name, CHANNEL_CATEGORIES["yangshi"]["lines"])
    # v2.00逻辑：优先4K、8K频道，然后按数字排序
    try:
        yangshi_lines_sorted = sorted(yangshi_lines, key=lambda x: (custom_sort(x), extract_number(x) if "CCTV" in x else 999))
    except Exception as e:
        yangshi_lines_sorted = sorted(yangshi_lines)
    
    all_lines_full.append("🌐央视频道,#genre#")
    all_lines_full.extend(yangshi_lines_sorted)
    all_lines_full.append('')
    
    # 卫视频道 - v2.00逻辑
    weishi_lines = correct_name_data(corrections_name, CHANNEL_CATEGORIES["weishi"]["lines"])
    weishi_lines_sorted = sort_data(dictionaries.get("weishi", []), weishi_lines)
    weishi_lines_unique = sorted(set(weishi_lines_sorted))
    
    all_lines_full.append("📡卫视频道,#genre#")
    all_lines_full.extend(weishi_lines_unique)
    all_lines_full.append('')
    
    # 地方台（按v2.00顺序和逻辑）
    local_order = [
        "beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
        "shandong", "sichuan", "henan", "hunan", "chongqing",
        "tianjin", "hubei", "anhui", "fujian", "liaoning", "shaanxi",
        "hebei", "jiangxi", "guangxi", "yunnan", "shanxi", "heilongjiang",
        "jilin", "guizhou", "gansu", "neimenggu", "xinjiang", "hainan",
        "ningxia", "qinghai", "xizang"
    ]
    
    for category_id in local_order:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 港澳台
    for category_id in ["hongkong", "macau", "taiwan"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 中国综合和国际频道
    for category_id in ["china", "international"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 数字频道
    for category_id in ["digital", "movie", "tv_drama", "documentary", "cartoon", "radio"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 虎牙、斗鱼、解说
    for category_id in ["huya", "douyu", "commentary"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 音乐、美食、旅游、健康、财经、购物
    for category_id in ["music", "food", "travel", "health", "finance", "shopping"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 游戏、新闻
    for category_id in ["game", "news"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 戏曲频道、综艺频道
    for category_id in ["traditional_opera", "variety"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            unique_lines = sorted(set(corrected_lines))
            all_lines_full.append(f"{config['title']},#genre#")
            all_lines_full.extend(unique_lines)
            all_lines_full.append('')
    
    # 历届春晚
    spring_festival_gala_lines = CHANNEL_CATEGORIES["spring_festival_gala"]["lines"]
    if spring_festival_gala_lines:
        sorted_lines = sort_data(dictionaries.get("spring_festival_gala", []), list(set(spring_festival_gala_lines)))
        all_lines_full.append("🧨历届春晚,#genre#")
        all_lines_full.extend(sorted_lines)
        all_lines_full.append('')
    
    # 收藏频道
    favorite_lines = CHANNEL_CATEGORIES["favorite"]["lines"]
    if favorite_lines:
        corrected_lines = correct_name_data(corrections_name, favorite_lines)
        sorted_lines = sort_data(dictionaries.get("favorite", []), corrected_lines)
        unique_lines = sorted(set(sorted_lines))
        all_lines_full.append("⭐收藏频道,#genre#")
        all_lines_full.extend(unique_lines)
        all_lines_full.append('')
    
    # 体育频道
    sports_lines = CHANNEL_CATEGORIES["sports"]["lines"]
    if sports_lines:
        corrected_lines = correct_name_data(corrections_name, sports_lines)
        unique_lines = sorted(set(corrected_lines))
        all_lines_full.append("⚽️体育频道,#genre#")
        all_lines_full.extend(unique_lines)
        all_lines_full.append('')
    
    # 体育赛事
    if filtered_tyss_lines:
        all_lines_full.append("🏆️体育赛事,#genre#")
        all_lines_full.extend(filtered_tyss_lines)
        all_lines_full.append('')
    
    # 咪咕赛事
    mgss_lines = CHANNEL_CATEGORIES["mgss"]["lines"]
    if mgss_lines:
        unique_lines = sorted(set(mgss_lines))
        all_lines_full.append("🏈咪咕赛事,#genre#")
        all_lines_full.extend(unique_lines)
        all_lines_full.append('')
    
    # 专享央视
    if zhuanxiang_yangshi:
        all_lines_full.append("👑专享央视,#genre#")
        all_lines_full.extend(zhuanxiang_yangshi)
        all_lines_full.append('')
    
    # 专享卫视
    if zhuanxiang_weishi:
        all_lines_full.append("☕️专享卫视,#genre#")
        all_lines_full.extend(zhuanxiang_weishi)
        all_lines_full.append('')
    
    # 景区直播
    camera_lines = CHANNEL_CATEGORIES["camera"]["lines"]
    if camera_lines:
        corrected_lines = correct_name_data(corrections_name, camera_lines)
        unique_lines = sorted(set(corrected_lines))
        all_lines_full.append("🏞️景区直播,#genre#")
        all_lines_full.extend(unique_lines)
        all_lines_full.append('')
    
    # 其他频道（v2.00逻辑：生成时去重）
    if other_lines:
        unique_lines = sorted(set(other_lines))
        all_lines_full.append("📦其他频道,#genre#")
        all_lines_full.extend(unique_lines)
        all_lines_full.append('')
    
    # 更新时间
    all_lines_full.append("🕒更新时间,#genre#")
    all_lines_full.append(version)
    all_lines_full.append(about)
    all_lines_full.append(MTV1)
    all_lines_full.append(MTV2)
    all_lines_full.append(MTV3)
    all_lines_full.append(MTV4)
    all_lines_full.append(MTV5)
    all_lines_full.extend(about_info)
    all_lines_full.append('')
    
    # ========= 构建精简版播放列表（与v2.00完全一致）=========
    print("✅ 构建精简版播放列表...")
    all_lines_lite = []
    
    # 央视频道
    all_lines_lite.append("🌐央视频道,#genre#")
    all_lines_lite.extend(yangshi_lines_sorted)
    all_lines_lite.append('')
    
    # 卫视频道
    all_lines_lite.append("📡卫视频道,#genre#")
    all_lines_lite.extend(weishi_lines_unique)
    all_lines_lite.append('')
    
    # 地·方·台（合并为一个分类）
    all_lines_lite.append("🏠地·方·台,#genre#")
    for category_id in local_order:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_lite.extend(unique_lines)
    all_lines_lite.append('')
    
    # 更新时间
    all_lines_lite.append("🕒更新时间,#genre#")
    all_lines_lite.append(version)
    all_lines_lite.append(about)
    all_lines_lite.append(MTV1)
    all_lines_lite.append(MTV2)
    all_lines_lite.append(MTV3)
    all_lines_lite.append(MTV4)
    all_lines_lite.append(MTV5)
    all_lines_lite.extend(about_info)
    all_lines_lite.append('')
    
    # ========= 构建定制版播放列表（与v2.00完全一致）=========
    print("✅ 构建定制版播放列表...")
    all_lines_custom = []
    
    # 央视频道
    all_lines_custom.append("🌐央视频道,#genre#")
    all_lines_custom.extend(yangshi_lines_sorted)
    all_lines_custom.append('')
    
    # 卫视频道
    all_lines_custom.append("📡卫视频道,#genre#")
    all_lines_custom.extend(weishi_lines_unique)
    all_lines_custom.append('')
    
    # 港澳台
    for category_id in ["hongkong", "macau", "taiwan"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 中国综合和国际频道
    for category_id in ["china", "international"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 数字频道
    for category_id in ["digital", "movie", "tv_drama", "documentary", "cartoon", "radio"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 虎牙、斗鱼
    for category_id in ["huya", "douyu"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 解说、音乐、美食、旅游、健康、财经、购物
    for category_id in ["commentary", "music", "food", "travel", "health", "finance", "shopping"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 游戏、新闻
    for category_id in ["game", "news"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            sorted_lines = sort_data(dictionaries.get(category_id, []), corrected_lines)
            unique_lines = sorted(set(sorted_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 戏曲频道、综艺频道
    for category_id in ["traditional_opera", "variety"]:
        config = CHANNEL_CATEGORIES[category_id]
        lines = config["lines"]
        if lines:
            corrected_lines = correct_name_data(corrections_name, lines)
            unique_lines = sorted(set(corrected_lines))
            all_lines_custom.append(f"{config['title']},#genre#")
            all_lines_custom.extend(unique_lines)
            all_lines_custom.append('')
    
    # 历届春晚
    if spring_festival_gala_lines:
        sorted_lines = sort_data(dictionaries.get("spring_festival_gala", []), list(set(spring_festival_gala_lines)))
        all_lines_custom.append("🧨历届春晚,#genre#")
        all_lines_custom.extend(sorted_lines)
        all_lines_custom.append('')
    
    # 收藏频道
    if favorite_lines:
        corrected_lines = correct_name_data(corrections_name, favorite_lines)
        sorted_lines = sort_data(dictionaries.get("favorite", []), corrected_lines)
        unique_lines = sorted(set(sorted_lines))
        all_lines_custom.append("⭐收藏频道,#genre#")
        all_lines_custom.extend(unique_lines)
        all_lines_custom.append('')
    
    # 体育频道
    if sports_lines:
        corrected_lines = correct_name_data(corrections_name, sports_lines)
        unique_lines = sorted(set(corrected_lines))
        all_lines_custom.append("⚽️体育频道,#genre#")
        all_lines_custom.extend(unique_lines)
        all_lines_custom.append('')
    
    # 体育赛事
    if filtered_tyss_lines:
        all_lines_custom.append("🏆️体育赛事,#genre#")
        all_lines_custom.extend(filtered_tyss_lines)
        all_lines_custom.append('')
    
    # 咪咕赛事
    if mgss_lines:
        unique_lines = sorted(set(mgss_lines))
        all_lines_custom.append("🏈咪咕赛事,#genre#")
        all_lines_custom.extend(unique_lines)
        all_lines_custom.append('')
    
    # 专享央视
    if zhuanxiang_yangshi:
        all_lines_custom.append("👑专享央视,#genre#")
        all_lines_custom.extend(zhuanxiang_yangshi)
        all_lines_custom.append('')
    
    # 专享卫视
    if zhuanxiang_weishi:
        all_lines_custom.append("☕️专享卫视,#genre#")
        all_lines_custom.extend(zhuanxiang_weishi)
        all_lines_custom.append('')
    
    # 景区直播
    if camera_lines:
        corrected_lines = correct_name_data(corrections_name, camera_lines)
        unique_lines = sorted(set(corrected_lines))
        all_lines_custom.append("🏞️景区直播,#genre#")
        all_lines_custom.extend(unique_lines)
        all_lines_custom.append('')
    
    # 其他频道
    if other_lines:
        unique_lines = sorted(set(other_lines))
        all_lines_custom.append("📦其他频道,#genre#")
        all_lines_custom.extend(unique_lines)
        all_lines_custom.append('')
    
    # 更新时间
    all_lines_custom.append("🕒更新时间,#genre#")
    all_lines_custom.append(version)
    all_lines_custom.append(about)
    all_lines_custom.append(MTV1)
    all_lines_custom.append(MTV2)
    all_lines_custom.append(MTV3)
    all_lines_custom.append(MTV4)
    all_lines_custom.append(MTV5)
    all_lines_custom.extend(about_info)
    all_lines_custom.append('')
    
    # 定义输出文件名
    output_others = "output/others.txt"
    output_full = "output/full.txt"
    output_lite = "output/lite.txt"
    output_custom = "output/custom.txt"
    
    # 写入文件
    try:
        with open(output_full, 'w', encoding='utf-8') as f:
            for line in all_lines_full:
                f.write(line + '\n')
        print(f"✅ 完整版播放列表已保存: {output_full}")
        
        with open(output_lite, 'w', encoding='utf-8') as f:
            for line in all_lines_lite:
                f.write(line + '\n')
        print(f"✅ 精简版播放列表已保存: {output_lite}")
        
        with open(output_custom, 'w', encoding='utf-8') as f:
            for line in all_lines_custom:
                f.write(line + '\n')
        print(f"✅ 定制版播放列表已保存: {output_custom}")
        
        with open(output_others, 'w', encoding='utf-8') as f:
            for line in other_lines:
                f.write(line + '\n')
        print(f"✅ 未分类频道列表已保存: {output_others}")
        
    except Exception as e:
        print(f"❌ 保存文件时发生错误：{e}")

# ========= 生成M3U格式文件 =========
def make_m3u(txt_file, m3u_file):
    """将TXT文件转换为M3U格式（与v2.00逻辑完全一致）"""
    try:
        channels_logos = read_txt_to_array('assets/livesource/logo.txt')
        
        def get_logo_by_channel_name(channel_name):
            for line in channels_logos:
                if not line.strip():
                    continue
                if ',' in line:
                    name, url = line.split(',', 1)
                    if name == channel_name:
                        return url
            return None
        
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        
        lines = input_text.strip().split("\n")
        group_name = ""
        
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1 tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\" group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)
        
        print(f"✅ M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"❌ 生成M3U文件错误: {e}")

# ========= 主函数 =========
def main():
    """主函数"""
    print("=" * 60)
    print("🎬 IPTV直播源聚合处理工具 v3.00 - 重构版（与v2.00输出对齐）")
    print("=" * 60)
    
    # 执行开始时间
    timestart = get_beijing_time()
    
    # 1. 加载字典
    load_dictionaries()
    
    # 2. 加载黑名单
    global combined_blacklist
    combined_blacklist = load_blacklist()
    
    # 3. 加载修正字典
    global corrections_name
    corrections_name = load_corrections_name()
    
    # 4. 处理URL列表
    urls = read_txt_to_array('assets/livesource/urls-daily.txt')
    print(f"\n📡 开始处理 {len(urls)} 个数据订阅源")
    
    for url in urls:
        if url.startswith("http"):
            # 处理日期占位符
            if "{MMdd}" in url:
                current_date_str = get_beijing_time().strftime("%m%d")
                url = url.replace("{MMdd}", current_date_str)
            if "{MMdd-1}" in url:
                yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                url = url.replace("{MMdd-1}", yesterday_date_str)
            
            print(f"📡 处理URL: {url}")
            process_url(url)
    
    # 5. 处理白名单
    process_whitelist()
    
    # 6. 处理AKTV源
    process_aktv()
    
    # 7. 处理手工区源
    process_manual_sources()
    
    # 8. 处理体育赛事
    filtered_tyss_lines = process_tyss_data()
    
    # 9. 生成输出文件（与v2.00保持一致）
    generate_output_files(filtered_tyss_lines)
    
    # 10. 生成M3U文件
    make_m3u("output/full.txt", "output/full.m3u")
    make_m3u("output/lite.txt", "output/lite.m3u")
    make_m3u("output/custom.txt", "output/custom.m3u")
    
    # 11. 统计信息
    timeend = get_beijing_time()
    elapsed_time = timeend - timestart
    total_seconds = elapsed_time.total_seconds()
    minutes = int(total_seconds // 60)
    seconds = int(total_seconds % 60)
    
    print(f"\n📊 处理统计:")
    print(f"   执行时间: {minutes}分{seconds}秒")
    
    # 显示各分类统计
    print(f"\n📈 分类统计:")
    total_channels = 0
    for category_id, config in CHANNEL_CATEGORIES.items():
        count = len(config["lines"])
        if count > 0:
            total_channels += count
    
    print(f"📊 总计: {total_channels} 个频道")
    
    # 去重统计信息
    processed_urls_count = len(processed_urls)
    blacklist_urls_count = len(combined_blacklist)
    total_processed_urls = processed_urls_count + blacklist_urls_count
    
    print(f"\n🔄 去重统计信息:")
    print(f"   处理的唯一URL数: {processed_urls_count}")
    print(f"   黑名单URL数: {blacklist_urls_count}")
    
    # 其他统计
    print(f"\n📦 其他统计:")
    print(f"   其他频道数: {len(other_lines)}")
    print(f"   体育赛事数: {len(filtered_tyss_lines) if filtered_tyss_lines else 0}")
    
    print("\n✅ 处理完成!")

# ========= 程序入口 =========
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断程序")
    except Exception as e:
        print(f"\n❌ 程序执行失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n💡 提示:")
    print("  v3.00重构版保持结构化风格，字典加载、频道分发和输出与v2.00完全一致")
    print("=" * 60)