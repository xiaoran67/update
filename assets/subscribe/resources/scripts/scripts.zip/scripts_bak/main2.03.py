#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.03 ======
# ======= LiveSource-Collector =======
# ===========  优化版============

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re  # 正则
import os
from datetime import datetime, timedelta, timezone
import random
import opencc  # 简繁转换
import socket
import time

# ========= 配置设置区 =========
# 输出目录设置
OUTPUT_DIR = 'output'

# 文件路径设置
URLS_FILE = 'assets/livesource/urls-daily.txt'
BLACKLIST_AUTO_FILE = 'assets/livesource/blacklist/blacklist_auto.txt'
BLACKLIST_MANUAL_FILE = 'assets/livesource/blacklist/blacklist_manual.txt'
WHITELIST_AUTO_FILE = 'assets/livesource/blacklist/whitelist_auto.txt'
CORRECTIONS_NAME_FILE = 'assets/livesource/corrections_name.txt'
CHANNEL_LOGOS_FILE = 'assets/livesource/logo.txt'

# AKTV相关设置
AKTV_URL = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
AKTV_LOCAL_FILE = 'assets/livesource/手工区/AKTV.txt'

# 今日推荐相关文件
TODAY_RECOMMEND_FILE = 'assets/livesource/手工区/今日推荐.txt'
TODAY_CHANNEL_FILE = 'assets/livesource/手工区/今日推台.txt'
ABOUT_FILE = 'assets/livesource/手工区/about.txt'

# 手工区高质量源文件
ZHEJIANG_MANUAL_FILE = 'assets/livesource/手工区/浙江频道.txt'
GUANGDONG_MANUAL_FILE = 'assets/livesource/手工区/广东频道.txt'
HUBEI_MANUAL_FILE = 'assets/livesource/手工区/湖北频道.txt'
SHANGHAI_MANUAL_FILE = 'assets/livesource/手工区/上海频道.txt'
JIANGSU_MANUAL_FILE = 'assets/livesource/手工区/江苏频道.txt'

# 优质频道文件
HIGH_QUALITY_CCTV_FILE = 'assets/livesource/手工区/优质央视.txt'
HIGH_QUALITY_WEISHI_FILE = 'assets/livesource/手工区/优质卫视.txt'
SPORTS_FILE = 'assets/livesource/手工区/sports.txt'

# 字典文件目录
DICTIONARY_DIR = 'assets/livesource/主频道'
LOCAL_DIR = 'assets/livesource/地方台'

# 字典文件设置
CCTV_DICT_FILE = f'{DICTIONARY_DIR}/CCTV.txt'
WEISHI_DICT_FILE = f'{DICTIONARY_DIR}/卫视.txt'
SPORTS_DICT_FILE = f'{DICTIONARY_DIR}/体育.txt'
TYSS_DICT_FILE = f'{DICTIONARY_DIR}/体育赛事.txt'
MGSS_DICT_FILE = f'{DICTIONARY_DIR}/咪咕赛事.txt'
DIGITAL_DICT_FILE = f'{DICTIONARY_DIR}/数字.txt'
MOVIE_DICT_FILE = f'{DICTIONARY_DIR}/电影.txt'
TV_DRAMA_DICT_FILE = f'{DICTIONARY_DIR}/电视剧.txt'
DOCUMENTARY_DICT_FILE = f'{DICTIONARY_DIR}/纪录片.txt'
CARTOON_DICT_FILE = f'{DICTIONARY_DIR}/动画片.txt'
RADIO_DICT_FILE = f'{DICTIONARY_DIR}/收音机.txt'
VARIETY_DICT_FILE = f'{DICTIONARY_DIR}/综艺.txt'
HUYA_DICT_FILE = f'{DICTIONARY_DIR}/虎牙.txt'
DOUYU_DICT_FILE = f'{DICTIONARY_DIR}/斗鱼.txt'
COMMENTARY_DICT_FILE = f'{DICTIONARY_DIR}/解说.txt'
MUSIC_DICT_FILE = f'{DICTIONARY_DIR}/音乐.txt'
FOOD_DICT_FILE = f'{DICTIONARY_DIR}/美食.txt'
TRAVEL_DICT_FILE = f'{DICTIONARY_DIR}/旅游.txt'
HEALTH_DICT_FILE = f'{DICTIONARY_DIR}/健康.txt'
FINANCE_DICT_FILE = f'{DICTIONARY_DIR}/财经.txt'
SHOPPING_DICT_FILE = f'{DICTIONARY_DIR}/购物.txt'
GAME_DICT_FILE = f'{DICTIONARY_DIR}/游戏.txt'
NEWS_DICT_FILE = f'{DICTIONARY_DIR}/新闻.txt'
CHINA_DICT_FILE = f'{DICTIONARY_DIR}/中国.txt'
INTERNATIONAL_DICT_FILE = f'{DICTIONARY_DIR}/国际.txt'
TRADITIONAL_OPERA_DICT_FILE = f'{DICTIONARY_DIR}/戏曲.txt'
SPRING_FESTIVAL_GALA_DICT_FILE = f'{DICTIONARY_DIR}/春晚.txt'
CAMERA_DICT_FILE = f'{DICTIONARY_DIR}/直播中国.txt'
FAVORITE_DICT_FILE = f'{DICTIONARY_DIR}/收藏频道.txt'

# 地方台字典文件
BEIJING_DICT_FILE = f'{LOCAL_DIR}/北京.txt'
SHANGHAI_DICT_FILE = f'{LOCAL_DIR}/上海.txt'
GUANGDONG_DICT_FILE = f'{LOCAL_DIR}/广东.txt'
JIANGSU_DICT_FILE = f'{LOCAL_DIR}/江苏.txt'
ZHEJIANG_DICT_FILE = f'{LOCAL_DIR}/浙江.txt'
SHANDONG_DICT_FILE = f'{LOCAL_DIR}/山东.txt'
SICHUAN_DICT_FILE = f'{LOCAL_DIR}/四川.txt'
HENAN_DICT_FILE = f'{LOCAL_DIR}/河南.txt'
HUNAN_DICT_FILE = f'{LOCAL_DIR}/湖南.txt'
CHONGQING_DICT_FILE = f'{LOCAL_DIR}/重庆.txt'
TIANJIN_DICT_FILE = f'{LOCAL_DIR}/天津.txt'
HUBEI_DICT_FILE = f'{LOCAL_DIR}/湖北.txt'
ANHUI_DICT_FILE = f'{LOCAL_DIR}/安徽.txt'
FUJIAN_DICT_FILE = f'{LOCAL_DIR}/福建.txt'
LIAONING_DICT_FILE = f'{LOCAL_DIR}/辽宁.txt'
SHAANXI_DICT_FILE = f'{LOCAL_DIR}/陕西.txt'
HEBEI_DICT_FILE = f'{LOCAL_DIR}/河北.txt'
JIANGXI_DICT_FILE = f'{LOCAL_DIR}/江西.txt'
GUANGXI_DICT_FILE = f'{LOCAL_DIR}/广西.txt'
YUNNAN_DICT_FILE = f'{LOCAL_DIR}/云南.txt'
SHANXI_DICT_FILE = f'{LOCAL_DIR}/山西.txt'
HEILONGJIANG_DICT_FILE = f'{LOCAL_DIR}/黑龙江.txt'
JILIN_DICT_FILE = f'{LOCAL_DIR}/吉林.txt'
GUIZHOU_DICT_FILE = f'{LOCAL_DIR}/贵州.txt'
GANSU_DICT_FILE = f'{LOCAL_DIR}/甘肃.txt'
NEIMENGGU_DICT_FILE = f'{LOCAL_DIR}/内蒙.txt'
XINJIANG_DICT_FILE = f'{LOCAL_DIR}/新疆.txt'
HAINAN_DICT_FILE = f'{LOCAL_DIR}/海南.txt'
NINGXIA_DICT_FILE = f'{LOCAL_DIR}/宁夏.txt'
QINGHAI_DICT_FILE = f'{LOCAL_DIR}/青海.txt'
XIZANG_DICT_FILE = f'{LOCAL_DIR}/西藏.txt'

# 港澳台字典文件
HONGKONG_DICT_FILE = f'{LOCAL_DIR}/香港.txt'
MACAU_DICT_FILE = f'{LOCAL_DIR}/澳门.txt'
MINNAN_DICT_FILE = f'{LOCAL_DIR}/闽南.txt'

# 输出文件设置
OUTPUT_OTHERS = f'{OUTPUT_DIR}/others.txt'
OUTPUT_FULL = f'{OUTPUT_DIR}/full.txt'
OUTPUT_LITE = f'{OUTPUT_DIR}/lite.txt'
OUTPUT_CUSTOM = f'{OUTPUT_DIR}/custom.txt'
OUTPUT_TIYU_TXT = f'{OUTPUT_DIR}/tiyu.txt'
OUTPUT_TIYU_HTML = f'{OUTPUT_DIR}/tiyu.html'

# HTTP请求设置
HTTP_TIMEOUT = 8
HTTP_RETRIES = 2
BACKOFF_FACTOR = 1.0

# 白名单响应时间阈值 (毫秒)
WHITELIST_RESPONSE_TIME_THRESHOLD = 2000

# 需要从频道名称中移除的字符串列表
removal_list = ["_电信","电信","频道","频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆",
    "肆柒","频英","频特","频国","频晴","频粤","高清","超清","标清","斯特","粤陆","国陆","频壹","频贰",
    "肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳","频效","国标","粤标","频推","频流","粤高",
    "频限","实时","美推","频美","英陆","(北美)","「回看」","[超清]","「IPV4」","「IPV6」","_ITV","(HK)",
    "AKtv","HD","[HD]","(HD)","（HD）","{HD}","<HD>","-HD","[BD]","SD","[SD]","(SD)","{SD}", "<SD>",
    "[VGA]","4Gtv","1080","720","480","VGA","4K","(4K)","{4K}","<4K>","(VGA)","{VGA}","<VGA>",
    "「4gTV」","「LiTV」"]

# User-Agent列表
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
]

# 体育赛事过滤关键词
KEYWORDS_TO_EXCLUDE_TIYU_TXT = ["玉玉软件", "榴芒电视","公众号","麻豆","「回看」"]
KEYWORDS_TO_EXCLUDE_TIYU_HTML = ["玉玉软件", "榴芒电视","公众号","咪视通","麻豆","「回看」"]

# 关于视频URL
ABOUT_VIDEO1 = "https://gitee.com/xiaoran67/update/raw/master/assets/livesource/about1080p.mp4"
ABOUT_VIDEO2 = "https://gitlab.com/xiaoran67/update/-/raw/main/assets/livesource/about1080p.mp4"

# ========= 初始化输出目录 =========
os.makedirs(OUTPUT_DIR, exist_ok=True)  # 创建输出目录，如果已存在则不会报错
print("创建输出目录: output")

# ========= 功能函数定义区 =========

# 简繁转换函数
def traditional_to_simplified(text: str) -> str:
    # 初始化转换器，"t2s" 表示从繁体转为简体
    converter = opencc.OpenCC('t2s')
    simplified_text = converter.convert(text)
    return simplified_text

# ========= 新增：获取北京时间的函数 =========
def get_beijing_time():
    """获取北京时间"""
    utc_now = datetime.now(timezone.utc)
    beijing_now = utc_now + timedelta(hours=8)
    return beijing_now

# 记录脚本开始执行的时间（改为北京时间）
timestart = get_beijing_time()  # 使用北京时间

# ========= 新增：全局URL去重集合 =========
processed_urls = set()  # 用于记录已处理的URL，全局去重

# 读取文本文件内容到数组的函数
def read_txt_to_array(file_name):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]  # 跳过空行
            return lines

    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_name}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_name}: {e}")
        return []

# 从文本文件读取黑名单的函数
def read_blacklist_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    BlackList = [line.split(',')[1].strip() for line in lines if ',' in line]
    return BlackList

# 读取自动和手动维护的黑名单，合并为集合去重
blacklist_auto=read_blacklist_from_txt(BLACKLIST_AUTO_FILE) 
blacklist_manual=read_blacklist_from_txt(BLACKLIST_MANUAL_FILE) 
combined_blacklist = set(blacklist_auto + blacklist_manual)

# ========= 新增添加黑名单信息打印 =========
print("🔴 黑名单统计信息:")
print(f"   自动维护: {len(blacklist_auto)} 条")
print(f"   手动维护: {len(blacklist_manual)} 条")
print(f"   合并去重: {len(combined_blacklist)} 条")

# 显示前几条黑名单示例
print("   黑名单示例 (前3条):")
for i, url in enumerate(list(combined_blacklist)[:3]):
    print(f"     {i+1}. {url}")
if len(combined_blacklist) > 3:
    print(f"     ... 还有 {len(combined_blacklist) - 3} 条")
print()
# =========end

# ========= 频道分类存储变量定义 =========

# 初始化各种频道类别的空列表，用于存储对应频道的播放源信息

yangshi_lines = []      # 存储央视频道数据
weishi_lines = []       # 存储卫视频道数据

beijing_lines = []      # 北京
shanghai_lines = []     # 上海
guangdong_lines = []    # 广东
jiangsu_lines = []      # 江苏
zhejiang_lines = []     # 浙江
shandong_lines = []     # 山东
sichuan_lines = []      # 四川
henan_lines = []        # 河南
hunan_lines = []        # 湖南
chongqing_lines = []    # 重庆
tianjin_lines = []      # 天津
hubei_lines = []        # 湖北
anhui_lines = []        # 安徽
fujian_lines = []       # 福建
liaoning_lines = []     # 辽宁
shaanxi_lines = []      # 陕西
hebei_lines = []        # 河北
jiangxi_lines = []      # 江西
guangxi_lines = []      # 广西
yunnan_lines = []       # 云南
shanxi_lines = []       # 山西
heilongjiang_lines = [] # 黑龙江
jilin_lines = []        # 吉林
guizhou_lines = []      # 贵州
gansu_lines = []        # 甘肃
neimenggu_lines = []    # 内蒙古
xinjiang_lines = []     # 新疆
hainan_lines = []       # 海南
ningxia_lines = []      # 宁夏
qinghai_lines = []      # 青海
xizang_lines = []       # 西藏

hongkong_lines = []    # 香港
macau_lines = []       # 澳门
minnan_lines = []      # 闽南

digital_lines = []     # 数字
movie_lines = []       # 电影
tv_drama_lines = []    # 电视剧
documentary_lines = [] # 纪录片
cartoon_lines = []     # 动画片
radio_lines = []       # 收音机
variety_lines = []     # 综艺
huya_lines = []        # 虎牙
douyu_lines = []       # 斗鱼
commentary_lines = []  # 解说
music_lines = []       # 音乐
food_lines = []        # 美食
travel_lines = []      # 旅游
health_lines = []      # 健康
finance_lines = []     # 财经
shopping_lines = []    # 购物
game_lines = []        # 游戏
news_lines = []        # 新闻
china_lines = []       # 中国
international_lines = [] # 国际
sports_lines = []      # 体育
tyss_lines = []        # 体育赛事
mgss_lines = []        # 咪咕赛事
traditional_opera_lines = [] # 戏曲频道
spring_festival_gala_lines = [] # 历届春晚
camera_lines = []      # 景区直播（直播中国）
favorite_lines = []    # 收藏频道

other_lines = []       # 其他未分类频道
other_lines_url = []    # 其他频道的URL列表

# 处理频道名称字符串的函数（主要用于处理CCTV频道名）
def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

# 处理单个频道名称部分的函数
def process_part(part_str):
    if "CCTV" in part_str  and "://" not in part_str:
        part_str=part_str.replace("IPV6", "")
        part_str=part_str.replace("PLUS", "+")
        part_str=part_str.replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str=part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV"+filtered_str 
        
    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    return part_str


# 获取URL文件扩展名的函数
def get_url_file_extension(url):
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

# 将M3U格式转换为TXT格式的函数
def convert_m3u_to_txt(m3u_content):
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p") :
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

# 清理URL的函数（移除$后的参数）
def clean_url(url):
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

# 清理频道名称的函数
def clean_channel_name(channel_name, removal_list):
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]

    return channel_name

# ========= 处理单行频道信息的函数（优化版） =========
def process_channel_line(line):
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        # 分割行，获取原始频道名称和URL
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        # ========== 优化1：提前清理URL ==========
        channel_address = clean_url(channel_address)
        
        # ========== 优化2：提前黑名单检查 ==========
        if channel_address in combined_blacklist:
            print(f"🚫 黑名单过滤: {channel_name}")
            return
        
        # ========== 优化3：全局URL去重检查 ==========
        if channel_address in processed_urls:
            print(f"🔄 URL去重: {channel_name}")
            return
        processed_urls.add(channel_address)
        # ======================================
        
        # 清理频道名称
        channel_name = clean_channel_name(channel_name, removal_list)
        # 繁体转简体
        channel_name = traditional_to_simplified(channel_name)
        
        # ========== 优化4：频道名称纠错 ==========
        if channel_name in corrections_name:
            corrected_name = corrections_name[channel_name]
            if corrected_name != channel_name:
                print(f"🔧 名称纠错: {channel_name} -> {corrected_name}")
                channel_name = corrected_name
        # ======================================
        
        # 重新组合行
        line = channel_name + "," + channel_address
        
        # ========= 央视频道 =========
        if "CCTV" in channel_name:
            yangshi_lines.append(process_name_string(line.strip()))
        # ========= 卫视频道 =========
        elif channel_name in weishi_dictionary:
            weishi_lines.append(process_name_string(line.strip()))
        # ========= 体育频道 =========
        elif channel_name in sports_dictionary:
            sports_lines.append(process_name_string(line.strip()))
        # ========= 体育赛事 =========
        elif any(tyss_keyword in channel_name for tyss_keyword in tyss_dictionary):
            tyss_lines.append(process_name_string(line.strip()))
        # ========= 咪咕赛事 =========
        elif any(mgss_keyword in channel_name for mgss_keyword in mgss_dictionary):
            mgss_lines.append(process_name_string(line.strip()))
        # ========= 地方台分类 =========
        elif channel_name in beijing_dictionary:
            beijing_lines.append(process_name_string(line.strip()))
        elif channel_name in shanghai_dictionary:
            shanghai_lines.append(process_name_string(line.strip()))
        elif channel_name in guangdong_dictionary:
            guangdong_lines.append(process_name_string(line.strip()))
        elif channel_name in jiangsu_dictionary:
            jiangsu_lines.append(process_name_string(line.strip()))
        elif channel_name in zhejiang_dictionary:
            zhejiang_lines.append(process_name_string(line.strip()))
        elif channel_name in shandong_dictionary:
            shandong_lines.append(process_name_string(line.strip()))
        elif channel_name in sichuan_dictionary:
            sichuan_lines.append(process_name_string(line.strip()))
        elif channel_name in henan_dictionary:
            henan_lines.append(process_name_string(line.strip()))
        elif channel_name in hunan_dictionary:
            hunan_lines.append(process_name_string(line.strip()))
        elif channel_name in chongqing_dictionary:
            chongqing_lines.append(process_name_string(line.strip()))
        elif channel_name in tianjin_dictionary:
            tianjin_lines.append(process_name_string(line.strip()))
        elif channel_name in hubei_dictionary:
            hubei_lines.append(process_name_string(line.strip()))
        elif channel_name in anhui_dictionary:
            anhui_lines.append(process_name_string(line.strip()))
        elif channel_name in fujian_dictionary:
            fujian_lines.append(process_name_string(line.strip()))
        elif channel_name in liaoning_dictionary:
            liaoning_lines.append(process_name_string(line.strip()))
        elif channel_name in shaanxi_dictionary:
            shaanxi_lines.append(process_name_string(line.strip()))
        elif channel_name in hebei_dictionary:
            hebei_lines.append(process_name_string(line.strip()))
        elif channel_name in jiangxi_dictionary:
            jiangxi_lines.append(process_name_string(line.strip()))
        elif channel_name in guangxi_dictionary:
            guangxi_lines.append(process_name_string(line.strip()))
        elif channel_name in yunnan_dictionary:
            yunnan_lines.append(process_name_string(line.strip()))
        elif channel_name in shanxi_dictionary:
            shanxi_lines.append(process_name_string(line.strip()))
        elif channel_name in heilongjiang_dictionary:
            heilongjiang_lines.append(process_name_string(line.strip()))
        elif channel_name in jilin_dictionary:
            jilin_lines.append(process_name_string(line.strip()))
        elif channel_name in guizhou_dictionary:
            guizhou_lines.append(process_name_string(line.strip()))
        elif channel_name in gansu_dictionary:
            gansu_lines.append(process_name_string(line.strip()))
        elif channel_name in neimenggu_dictionary:
            neimenggu_lines.append(process_name_string(line.strip()))
        elif channel_name in xinjiang_dictionary:
            xinjiang_lines.append(process_name_string(line.strip()))
        elif channel_name in hainan_dictionary:
            hainan_lines.append(process_name_string(line.strip()))
        elif channel_name in ningxia_dictionary:
            ningxia_lines.append(process_name_string(line.strip()))
        elif channel_name in qinghai_dictionary:
            qinghai_lines.append(process_name_string(line.strip()))
        elif channel_name in xizang_dictionary:
            xizang_lines.append(process_name_string(line.strip()))
        # ========= 港澳台分类 =========
        elif channel_name in hongkong_dictionary:
            hongkong_lines.append(process_name_string(line.strip()))
        elif channel_name in macau_dictionary:
            macau_lines.append(process_name_string(line.strip()))
        elif channel_name in minnan_dictionary:
            minnan_lines.append(process_name_string(line.strip()))
        # ========= 定制分类 =========
        elif channel_name in digital_dictionary:
            digital_lines.append(process_name_string(line.strip()))
        elif channel_name in movie_dictionary:
            movie_lines.append(process_name_string(line.strip()))
        elif channel_name in tv_drama_dictionary:
            tv_drama_lines.append(process_name_string(line.strip()))
        elif channel_name in documentary_dictionary:
            documentary_lines.append(process_name_string(line.strip()))
        elif channel_name in cartoon_dictionary:
            cartoon_lines.append(process_name_string(line.strip()))
        elif channel_name in radio_dictionary:
            radio_lines.append(process_name_string(line.strip()))
        elif channel_name in variety_dictionary:
            variety_lines.append(process_name_string(line.strip()))
        elif channel_name in huya_dictionary:
            huya_lines.append(process_name_string(line.strip()))
        elif channel_name in douyu_dictionary:
            douyu_lines.append(process_name_string(line.strip()))
        elif channel_name in commentary_dictionary:
            commentary_lines.append(process_name_string(line.strip()))
        elif channel_name in music_dictionary:
            music_lines.append(process_name_string(line.strip()))
        elif channel_name in food_dictionary:
            food_lines.append(process_name_string(line.strip()))
        elif channel_name in travel_dictionary:
            travel_lines.append(process_name_string(line.strip()))
        elif channel_name in health_dictionary:
            health_lines.append(process_name_string(line.strip()))
        elif channel_name in finance_dictionary:
            finance_lines.append(process_name_string(line.strip()))
        elif channel_name in shopping_dictionary:
            shopping_lines.append(process_name_string(line.strip()))
        elif channel_name in game_dictionary:
            game_lines.append(process_name_string(line.strip()))
        elif channel_name in news_dictionary:
            news_lines.append(process_name_string(line.strip()))
        elif channel_name in china_dictionary:
            china_lines.append(process_name_string(line.strip()))
        elif channel_name in international_dictionary:
            international_lines.append(process_name_string(line.strip()))
        elif channel_name in traditional_opera_dictionary:
            traditional_opera_lines.append(process_name_string(line.strip()))
        elif channel_name in spring_festival_gala_dictionary:
            spring_festival_gala_lines.append(process_name_string(line.strip()))
        elif channel_name in camera_dictionary:
            camera_lines.append(process_name_string(line.strip()))
        elif channel_name in favorite_dictionary:
            favorite_lines.append(process_name_string(line.strip()))
        # ========= 未匹配到任何分类，放入other_lines =========
        else:
            # 使用全局去重，这里可以简化
            if channel_address not in other_lines_url:  # 保留原有的逻辑，但理论上全局去重已经处理了
                other_lines_url.append(channel_address)
                other_lines.append(line.strip())

# 获取随机User-Agent的函数
def get_random_user_agent():
    return random.choice(USER_AGENTS)

# 处理单个URL的函数
def process_url(url):
    try:
        other_lines.append("◆◆◆　"+url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url)==".m3u" or get_url_file_extension(url)==".m3u8" or is_m3u:
                text=convert_m3u_to_txt(text)

            lines = text.split('\n')
            print(f"行数: {len(lines)}")

            for line in lines:
                if  "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    channel_name, channel_address = line.split(',', 1)
                    if "#" not in channel_address:
                        process_channel_line(line)
                    else:
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline=f'{channel_name},{channel_url}'
                            process_channel_line(newline)

            other_lines.append('\n')

    except Exception as e:
        print(f"❌处理URL时发生错误：{e}")

# 获取当前工作目录
current_directory = os.getcwd()

# ======== 频道字典文件读取 =========

# 读取各种频道的字典文件（用于频道分类）
print("📋 加载频道字典...")

yangshi_dictionary = read_txt_to_array(CCTV_DICT_FILE)
weishi_dictionary = read_txt_to_array(WEISHI_DICT_FILE)

beijing_dictionary = read_txt_to_array(BEIJING_DICT_FILE)
shanghai_dictionary = read_txt_to_array(SHANGHAI_DICT_FILE)
guangdong_dictionary = read_txt_to_array(GUANGDONG_DICT_FILE)
jiangsu_dictionary = read_txt_to_array(JIANGSU_DICT_FILE)
zhejiang_dictionary = read_txt_to_array(ZHEJIANG_DICT_FILE)
shandong_dictionary = read_txt_to_array(SHANDONG_DICT_FILE)
sichuan_dictionary = read_txt_to_array(SICHUAN_DICT_FILE)
henan_dictionary = read_txt_to_array(HENAN_DICT_FILE)
hunan_dictionary = read_txt_to_array(HUNAN_DICT_FILE)
chongqing_dictionary = read_txt_to_array(CHONGQING_DICT_FILE)
tianjin_dictionary = read_txt_to_array(TIANJIN_DICT_FILE)
hubei_dictionary = read_txt_to_array(HUBEI_DICT_FILE)
anhui_dictionary = read_txt_to_array(ANHUI_DICT_FILE)
fujian_dictionary = read_txt_to_array(FUJIAN_DICT_FILE)
liaoning_dictionary = read_txt_to_array(LIAONING_DICT_FILE)
shaanxi_dictionary = read_txt_to_array(SHAANXI_DICT_FILE)
hebei_dictionary = read_txt_to_array(HEBEI_DICT_FILE)
jiangxi_dictionary = read_txt_to_array(JIANGXI_DICT_FILE)
guangxi_dictionary = read_txt_to_array(GUANGXI_DICT_FILE)
yunnan_dictionary = read_txt_to_array(YUNNAN_DICT_FILE)
shanxi_dictionary = read_txt_to_array(SHANXI_DICT_FILE)
heilongjiang_dictionary = read_txt_to_array(HEILONGJIANG_DICT_FILE)
jilin_dictionary = read_txt_to_array(JILIN_DICT_FILE)
guizhou_dictionary = read_txt_to_array(GUIZHOU_DICT_FILE)
gansu_dictionary = read_txt_to_array(GANSU_DICT_FILE)
neimenggu_dictionary = read_txt_to_array(NEIMENGGU_DICT_FILE)
xinjiang_dictionary = read_txt_to_array(XINJIANG_DICT_FILE)
hainan_dictionary = read_txt_to_array(HAINAN_DICT_FILE)
ningxia_dictionary = read_txt_to_array(NINGXIA_DICT_FILE)
qinghai_dictionary = read_txt_to_array(QINGHAI_DICT_FILE)
xizang_dictionary = read_txt_to_array(XIZANG_DICT_FILE)

hongkong_dictionary = read_txt_to_array(HONGKONG_DICT_FILE)
macau_dictionary = read_txt_to_array(MACAU_DICT_FILE)
minnan_dictionary = read_txt_to_array(MINNAN_DICT_FILE)

digital_dictionary = read_txt_to_array(DIGITAL_DICT_FILE)
movie_dictionary = read_txt_to_array(MOVIE_DICT_FILE)
tv_drama_dictionary = read_txt_to_array(TV_DRAMA_DICT_FILE)
documentary_dictionary = read_txt_to_array(DOCUMENTARY_DICT_FILE)
cartoon_dictionary = read_txt_to_array(CARTOON_DICT_FILE)
radio_dictionary = read_txt_to_array(RADIO_DICT_FILE)
variety_dictionary = read_txt_to_array(VARIETY_DICT_FILE)
huya_dictionary = read_txt_to_array(HUYA_DICT_FILE)
douyu_dictionary = read_txt_to_array(DOUYU_DICT_FILE)
commentary_dictionary = read_txt_to_array(COMMENTARY_DICT_FILE)
music_dictionary = read_txt_to_array(MUSIC_DICT_FILE)
food_dictionary = read_txt_to_array(FOOD_DICT_FILE)
travel_dictionary = read_txt_to_array(TRAVEL_DICT_FILE)
health_dictionary = read_txt_to_array(HEALTH_DICT_FILE)
finance_dictionary = read_txt_to_array(FINANCE_DICT_FILE)
shopping_dictionary = read_txt_to_array(SHOPPING_DICT_FILE)
game_dictionary = read_txt_to_array(GAME_DICT_FILE)
news_dictionary = read_txt_to_array(NEWS_DICT_FILE)
china_dictionary = read_txt_to_array(CHINA_DICT_FILE)
international_dictionary = read_txt_to_array(INTERNATIONAL_DICT_FILE)
sports_dictionary = read_txt_to_array(SPORTS_DICT_FILE)
tyss_dictionary = read_txt_to_array(TYSS_DICT_FILE)
mgss_dictionary = read_txt_to_array(MGSS_DICT_FILE)
traditional_opera_dictionary = read_txt_to_array(TRADITIONAL_OPERA_DICT_FILE)
spring_festival_gala_dictionary = read_txt_to_array(SPRING_FESTIVAL_GALA_DICT_FILE)
camera_dictionary = read_txt_to_array(CAMERA_DICT_FILE)
favorite_dictionary = read_txt_to_array(FAVORITE_DICT_FILE)

# 打印所有字典加载情况
print(f"✅ 字典加载完成:")
print(f"   央视: {len(yangshi_dictionary)} 条")
print(f"   卫视: {len(weishi_dictionary)} 条")
print(f"   地方台: 31个分类已加载")
print(f"   港澳台: 3个分类已加载")
print(f"   其他分类: 27个分类已加载")

# 加载频道名称修正字典的函数
def load_corrections_name(filename):
    corrections = {}
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # 跳过空行和以#开头的注释行
                if not line or line.startswith('#'):
                    continue
                parts = line.strip().split(',')
                if len(parts) < 2:
                    continue  # 跳过不完整的行
                correct_name = parts[0]
                for name in parts[1:]:
                    if name:  # 跳过空的别名
                        corrections[name] = correct_name
    except FileNotFoundError:
        print(f"❌ 修正字典文件未找到: {filename}")
    except Exception as e:
        print(f"❌ 加载修正字典错误: {e}")
    return corrections

# 加载名称修正字典
corrections_name = load_corrections_name(CORRECTIONS_NAME_FILE)
# ========= 新增添加频道更名信息打印 =========
print("🔄 频道更名修正字典:")
print(f"   加载了 {len(corrections_name)} 条修正规则")
if corrections_name:
    print("   修正规则示例 (前3条):")
    for i, (wrong_name, correct_name) in enumerate(list(corrections_name.items())[:3]):
        print(f"     {i+1}. '{wrong_name}' → '{correct_name}'")
    if len(corrections_name) > 3:
        print(f"     ... 还有 {len(corrections_name) - 3} 条修正规则")
else:
    print("   未加载到有效的修正规则")
print()
# =========end

# 修正频道名称数据的函数
def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

# 按指定顺序排序数据的函数
def sort_data(order, data):
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# 读取URL列表文件
urls = read_txt_to_array(URLS_FILE)
print(f"📋 发现 {len(urls)} 个数据订阅源")
for url in urls:
    if url.startswith("http"):
        if "{MMdd}" in url:
            current_date_str = get_beijing_time().strftime("%m%d")
            url=url.replace("{MMdd}", current_date_str)
        if "{MMdd-1}" in url:
            yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
            url=url.replace("{MMdd-1}", yesterday_date_str)
        print(f"📡 处理URL: {url}")
        process_url(url)

# 从字符串中提取数字的函数（用于排序）
def extract_number(s):
    num_str = s.split(',')[0].split('-')[1]
    numbers = re.findall(r'\d+', num_str)
    return int(numbers[-1]) if numbers else 999

# 自定义排序函数（优先4K、8K频道）
def custom_sort(s):
    if "CCTV-4K" in s:
        return 2
    elif "CCTV-8K" in s:
        return 3
    elif "(4K)" in s:
        return 1
    else:
        return 0

# 处理白名单自动文件
print("🟢 处理白名单自动文件...")
whitelist_auto_lines = read_txt_to_array(WHITELIST_AUTO_FILE)

# ========= 新增添加白名单信息打印开始 =========
# 打印白名单统计信息
print(f"   读取到 {len(whitelist_auto_lines)} 条记录")
print(f"   跳过标题行和表头...")

# 统计有效白名单记录
valid_whitelist_count = 0
valid_whitelist_samples = []

for i, whitelist_line in enumerate(whitelist_auto_lines):
    if i < 2:  # 跳过前两行（标题和日期行）
        continue
    
    # 跳过表头行
    if whitelist_line.startswith("RespoTime,whitelist,#genre#"):
        continue
        
    # 处理真正的白名单行
    if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        if len(whitelist_parts) >= 3:
            valid_whitelist_count += 1
            
            # 保存示例
            if len(valid_whitelist_samples) < 3:
                valid_whitelist_samples.append(whitelist_line)
            
            try:
                response_time = float(whitelist_parts[0].replace("ms", ""))
            except ValueError:
                print(f"response_time转换失败: {whitelist_line}")
                response_time = 60000
            if response_time < WHITELIST_RESPONSE_TIME_THRESHOLD:
                process_channel_line(",".join(whitelist_parts[1:]))

print(f"   有效白名单记录: {valid_whitelist_count} 条")
if valid_whitelist_samples:
    print("   白名单示例 (前3条):")
    for i, line in enumerate(valid_whitelist_samples[:3]):
        print(f"     {i+1}. {line[:80]}..." if len(line) > 80 else f"     {i+1}. {line}")
    if valid_whitelist_count > 3:
        print(f"     ... 还有 {valid_whitelist_count - 3} 条")
print()

for whitelist_line in whitelist_auto_lines:
    if  "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        try:
            response_time = float(whitelist_parts[0].replace("ms", ""))
        except ValueError:
            print(f"response_time转换失败: {whitelist_line}")
            response_time = 60000
        if response_time < WHITELIST_RESPONSE_TIME_THRESHOLD:
            process_channel_line(",".join(whitelist_parts[1:]))

# 获取HTTP响应的函数（带重试机制）
def get_http_response(url, timeout=HTTP_TIMEOUT, retries=HTTP_RETRIES, backoff_factor=BACKOFF_FACTOR):
    headers = {
        'User-Agent': get_random_user_agent()
    }
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
            if attempt < retries - 1:
                time.sleep(backoff_factor * (2 ** attempt))
    return None
    
# 将日期格式规范化为MM-DD格式的函数
def normalize_date_to_md(text):
    text = text.strip()
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

# 规范化体育赛事行的日期格式
normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]

# ========= AKTV特殊处理 =========
# 获取AKTV直播源
aktv_lines = []  # 存储AKTV频道数据
aktv_text = get_http_response(AKTV_URL)
if aktv_text:
    print("AKTV成功获取内容")
    aktv_text = convert_m3u_to_txt(aktv_text)
    aktv_lines = aktv_text.strip().split('\n')
else:
    print("AKTV请求失败，从本地获取！")
    aktv_lines = read_txt_to_array(AKTV_LOCAL_FILE)

# ========= 新增添加AKTV信息打印 =========
print("📺 AKTV频道统计:")
print(f"   获取到 {len(aktv_lines)} 条AKTV频道记录")
if aktv_lines:
    print("   AKTV频道示例 (前3条):")
    for i, line in enumerate(aktv_lines[:3]):
        print(f"     {i+1}. {line[:60]}..." if len(line) > 60 else f"     {i+1}. {line}")
    if len(aktv_lines) > 3:
        print(f"     ... 还有 {len(aktv_lines) - 3} 条")
print()

# 处理AKTV数据
print(f"处理AKTV数据，共 {len(aktv_lines)} 行")
for line in aktv_lines:
    process_channel_line(line)

# 过滤包含特定关键词的行的函数
def filter_lines(lines, exclude_keywords):
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

# 生成体育赛事HTML页面的函数
def generate_playlist_html(data_list, output_file='playlist.html'):
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''

    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''

    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 网页已生成：{output_file}")

# 自定义体育赛事排序函数（数字前缀的倒序，其他正序）
def custom_tyss_sort(lines):
    digit_prefix = []
    others = []
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

# 过滤体育赛事文本中的特定关键词
normalized_tyss_lines = filter_lines(normalized_tyss_lines, KEYWORDS_TO_EXCLUDE_TIYU_TXT)
# 去重并排序
normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))

# 过滤体育赛事HTML中的特定关键词
filtered_tyss_lines = filter_lines(normalized_tyss_lines, KEYWORDS_TO_EXCLUDE_TIYU_HTML)
print(f"🏆 体育赛事处理完成：原始 {len(tyss_lines)} 条，过滤后 {len(filtered_tyss_lines)} 条")

# 生成体育赛事HTML文件
generate_playlist_html(filtered_tyss_lines, OUTPUT_TIYU_HTML)

# 生成体育赛事TXT文件
with open(OUTPUT_TIYU_TXT, 'w', encoding='utf-8') as f:
    for line in filtered_tyss_lines:
        f.write(line + '\n')
print(f"✅ 文本已生成: {OUTPUT_TIYU_TXT}")

# 从文件中随机获取URL的函数
def get_random_url(file_path):
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            url = line.strip().split(',')[-1]
            urls.append(url)    
    return random.choice(urls) if urls else None

# ========= 今日推荐和版本信息 =========
print("🕒 生成今日推荐和版本信息")
# 获取北京时间
utc_time = datetime.now(timezone.utc)
beijing_time = utc_time + timedelta(hours=8)
formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")

# 生成今日推荐信息
MTV1 = "💯推荐," + get_random_url(TODAY_RECOMMEND_FILE)
MTV2 = "🤫低调," + get_random_url(TODAY_RECOMMEND_FILE)
MTV3 = "🟢使用," + get_random_url(TODAY_RECOMMEND_FILE)
MTV4 = "⚠️禁止," + get_random_url(TODAY_RECOMMEND_FILE)
MTV5 = "🚫贩卖," + get_random_url(TODAY_RECOMMEND_FILE)

# 生成版本信息
version = formatted_time + "," + get_random_url(TODAY_CHANNEL_FILE)
about = "👨潇然," + get_random_url(TODAY_CHANNEL_FILE)

# 处理手工添加的频道源
print(f"🔧 处理手工区高质量源...")

# 读取并统计各个手工区文件
zhejiang_manual = read_txt_to_array(ZHEJIANG_MANUAL_FILE)
guangdong_manual = read_txt_to_array(GUANGDONG_MANUAL_FILE)
hubei_manual = read_txt_to_array(HUBEI_MANUAL_FILE)
shanghai_manual = read_txt_to_array(SHANGHAI_MANUAL_FILE)
jiangsu_manual = read_txt_to_array(JIANGSU_MANUAL_FILE)

# 打印手工区统计信息
print(f"   浙江频道: {len(zhejiang_manual)} 条")
print(f"   广东频道: {len(guangdong_manual)} 条")
print(f"   湖北频道: {len(hubei_manual)} 条")
print(f"   上海频道: {len(shanghai_manual)} 条")
print(f"   江苏频道: {len(jiangsu_manual)} 条")
print(f"   手工区总计: {len(zhejiang_manual) + len(guangdong_manual) + len(hubei_manual) + len(shanghai_manual) + len(jiangsu_manual)} 条")
print()

# 添加到对应的频道列表
zhejiang_lines += zhejiang_manual
guangdong_lines += guangdong_manual
hubei_lines += hubei_manual
shanghai_lines += shanghai_manual
jiangsu_lines += jiangsu_manual

print("📄 生成播放列表文件")

# 构建完整版播放列表
all_lines_full =  ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🏛️北京频道,#genre#"] + sort_data(beijing_dictionary, correct_name_data(corrections_name, beijing_lines)) + ['\n'] + \
        ["🏙️上海频道,#genre#"] + sort_data(shanghai_dictionary, correct_name_data(corrections_name, shanghai_lines)) + ['\n'] + \
        ["🐯广东频道,#genre#"] + sort_data(guangdong_dictionary,set(correct_name_data(corrections_name,guangdong_lines))) + ['\n'] + \
        ["🎐江苏频道,#genre#"] + sort_data(jiangsu_dictionary, correct_name_data(corrections_name, jiangsu_lines)) + ['\n'] + \
        ["🧵浙江频道,#genre#"] + sort_data(zhejiang_dictionary, correct_name_data(corrections_name, zhejiang_lines)) + ['\n'] + \
        ["⛰️山东频道,#genre#"] + sort_data(shandong_dictionary, correct_name_data(corrections_name, shandong_lines)) + ['\n'] + \
        ["🐼四川频道,#genre#"] + sort_data(sichuan_dictionary, correct_name_data(corrections_name, sichuan_lines)) + ['\n'] + \
        ["🐘河南频道,#genre#"] + sorted(set(correct_name_data(corrections_name,henan_lines))) + ['\n'] + \
        ["⛩️河北频道,#genre#"] + sorted(set(correct_name_data(corrections_name,hebei_lines))) + ['\n'] + \
        ["🌶️湖南频道,#genre#"] + sort_data(hunan_dictionary,correct_name_data(corrections_name,hunan_lines)) + ['\n'] + \
        ["🏞️重庆频道,#genre#"] + sort_data(chongqing_dictionary, correct_name_data(corrections_name, chongqing_lines)) + ['\n'] + \
        ["🚢天津频道,#genre#"] + sort_data(tianjin_dictionary, correct_name_data(corrections_name, tianjin_lines)) + ['\n'] + \
        ["🏯湖北频道,#genre#"] + sort_data(hubei_dictionary,correct_name_data(corrections_name,hubei_lines)) + ['\n'] + \
        ["🌾安徽频道,#genre#"] + sort_data(anhui_dictionary, correct_name_data(corrections_name, anhui_lines)) + ['\n'] + \
        ["🌊福建频道,#genre#"] + sort_data(fujian_dictionary, correct_name_data(corrections_name, fujian_lines)) + ['\n'] + \
        ["⛰️辽宁频道,#genre#"] + sort_data(liaoning_dictionary, correct_name_data(corrections_name, liaoning_lines)) + ['\n'] + \
        ["🔥陕西频道,#genre#"] + sort_data(shaanxi_dictionary, correct_name_data(corrections_name, shaanxi_lines)) + ['\n'] + \
        ["⛩️河北频道,#genre#"] + sort_data(hebei_dictionary, correct_name_data(corrections_name, hebei_lines)) + ['\n'] + \
        ["🔥江西频道,#genre#"] + sort_data(jiangxi_dictionary, correct_name_data(corrections_name, jiangxi_lines)) + ['\n'] + \
        ["💃广西频道,#genre#"] + sort_data(guangxi_dictionary,set(correct_name_data(corrections_name,guangxi_lines))) + ['\n'] + \
        ["☁️云南频道,#genre#"] + sort_data(yunnan_dictionary, correct_name_data(corrections_name, yunnan_lines)) + ['\n'] + \
        ["🏮山西频道,#genre#"] + sort_data(shanxi_dictionary, correct_name_data(corrections_name, shanxi_lines)) + ['\n'] + \
        ["🐻黑·龙·江,#genre#"] + sort_data(heilongjiang_dictionary, correct_name_data(corrections_name, heilongjiang_lines)) + ['\n'] + \
        ["🎎吉林频道,#genre#"] + sort_data(jilin_dictionary, correct_name_data(corrections_name, jilin_lines)) + ['\n'] + \
        ["⛰️贵州频道,#genre#"] + sort_data(guizhou_dictionary, correct_name_data(corrections_name, guizhou_lines)) + ['\n'] + \
        ["🐫甘肃频道,#genre#"] + sort_data(gansu_dictionary, correct_name_data(corrections_name, gansu_lines)) + ['\n'] + \
        ["🐮内·蒙·古,#genre#"] + sort_data(neimenggu_dictionary, correct_name_data(corrections_name, neimenggu_lines)) + ['\n'] + \
        ["🍇新疆频道,#genre#"] + sort_data(xinjiang_dictionary, correct_name_data(corrections_name, xinjiang_lines)) + ['\n'] + \
        ["🏝️海南频道,#genre#"] + sort_data(hainan_dictionary, correct_name_data(corrections_name, hainan_lines)) + ['\n'] + \
        ["🕌宁夏频道,#genre#"] + sort_data(ningxia_dictionary, correct_name_data(corrections_name, ningxia_lines)) + ['\n'] + \
        ["🐑青海频道,#genre#"] + sort_data(qinghai_dictionary, correct_name_data(corrections_name, qinghai_lines)) + ['\n'] + \
        ["🐐西藏频道,#genre#"] + sort_data(xizang_dictionary, correct_name_data(corrections_name, xizang_lines)) + ['\n'] + \
        ["☕️专享央视,#genre#"] + read_txt_to_array(HIGH_QUALITY_CCTV_FILE) + ['\n'] + \
        ["🍹专享卫视,#genre#"] + read_txt_to_array(HIGH_QUALITY_WEISHI_FILE) + ['\n'] + \
        ["⚽️SPORTS,#genre#"] + read_txt_to_array(SPORTS_FILE) + ['\n'] + \
        ["🏆️体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + mgss_lines + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary, correct_name_data(corrections_name, hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary, correct_name_data(corrections_name, macau_lines)) + ['\n'] + \
        ["🇨🇳闽南频道,#genre#"] + sort_data(minnan_dictionary, correct_name_data(corrections_name, minnan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary, correct_name_data(corrections_name, digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary, correct_name_data(corrections_name, movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary,correct_name_data(corrections_name,tv_drama_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary,set(correct_name_data(corrections_name,cartoon_lines)))+ ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary,set(correct_name_data(corrections_name,documentary_lines)))+ ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary,set(radio_lines))  + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(corrections_name, variety_lines))) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary, correct_name_data(corrections_name, huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary, correct_name_data(corrections_name, douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sorted(set(commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sorted(set(music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary, correct_name_data(corrections_name, food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary, correct_name_data(corrections_name, travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary, correct_name_data(corrections_name, health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary, correct_name_data(corrections_name, finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary, correct_name_data(corrections_name, shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sorted(set(game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary, correct_name_data(corrections_name, news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary, correct_name_data(corrections_name, china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary, correct_name_data(corrections_name, international_lines)) + ['\n'] + \
        ["🏀体育频道,#genre#"] + sort_data(sports_dictionary,correct_name_data(corrections_name,sports_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary, correct_name_data(corrections_name, traditional_opera_lines)) + ['\n'] + \
        ["🧨历届春晚,#genre#"] + sort_data(spring_festival_gala_dictionary,set(spring_festival_gala_lines))  + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(corrections_name,camera_lines))) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary, correct_name_data(corrections_name, favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array(ABOUT_FILE) + ['\n']

# 构建精简版播放列表
all_lines_lite =  ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array(ABOUT_FILE) + ['\n']

# 构建定制版播放列表
all_lines_custom = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, correct_name_data(corrections_name, yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, correct_name_data(corrections_name, weishi_lines)) + ['\n'] + \
        ["☕️专享央视,#genre#"] + read_txt_to_array(HIGH_QUALITY_CCTV_FILE) + ['\n'] + \
        ["🍹专享卫视,#genre#"] + read_txt_to_array(HIGH_QUALITY_WEISHI_FILE) + ['\n'] + \
        ["⚽️SPORTS,#genre#"] + read_txt_to_array(SPORTS_FILE) + ['\n'] + \
        ["🏆️体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + mgss_lines + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary, correct_name_data(corrections_name, hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary, correct_name_data(corrections_name, macau_lines)) + ['\n'] + \
        ["🇨🇳闽南频道,#genre#"] + sort_data(minnan_dictionary, correct_name_data(corrections_name, minnan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary, correct_name_data(corrections_name, digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary, correct_name_data(corrections_name, movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary,correct_name_data(corrections_name,tv_drama_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary,set(correct_name_data(corrections_name,cartoon_lines)))+ ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary,set(correct_name_data(corrections_name,documentary_lines)))+ ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary,set(radio_lines))  + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(corrections_name, variety_lines))) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary, correct_name_data(corrections_name, huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary, correct_name_data(corrections_name, douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sorted(set(commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sorted(set(music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary, correct_name_data(corrections_name, food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary, correct_name_data(corrections_name, travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary, correct_name_data(corrections_name, health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary, correct_name_data(corrections_name, finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary, correct_name_data(corrections_name, shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sorted(set(game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary, correct_name_data(corrections_name, news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary, correct_name_data(corrections_name, china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary, correct_name_data(corrections_name, international_lines)) + ['\n'] + \
        ["🏀体育频道,#genre#"] + sort_data(sports_dictionary,correct_name_data(corrections_name,sports_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary, correct_name_data(corrections_name, traditional_opera_lines)) + ['\n'] + \
        ["🧨历届春晚,#genre#"] + sort_data(spring_festival_gala_dictionary,set(spring_festival_gala_lines))  + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(corrections_name,camera_lines))) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary, correct_name_data(corrections_name, favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array(ABOUT_FILE) + ['\n']

# 写入文件
try:
    with open(OUTPUT_FULL, 'w', encoding='utf-8') as f:
        for line in all_lines_full:
            f.write(line + '\n')
    print(f"✅ 完整版播放列表已保存: {OUTPUT_FULL}")

    with open(OUTPUT_LITE, 'w', encoding='utf-8') as f:
        for line in all_lines_lite:
            f.write(line + '\n')
    print(f"✅ 精简版播放列表已保存: {OUTPUT_LITE}")

    with open(OUTPUT_CUSTOM, 'w', encoding='utf-8') as f:
        for line in all_lines_custom:
            f.write(line + '\n')
    print(f"✅ 定制版播放列表已保存: {OUTPUT_CUSTOM}")

    with open(OUTPUT_OTHERS, 'w', encoding='utf-8') as f:
        for line in other_lines:
            f.write(line + '\n')
    print(f"✅ 未分类频道列表已保存: {OUTPUT_OTHERS}")

except Exception as e:
    print(f"保存文件时发生错误：{e}")

# 读取频道Logo信息
channels_logos=read_txt_to_array(CHANNEL_LOGOS_FILE)

# 根据频道名称获取Logo URL的函数
def get_logo_by_channel_name(channel_name):
    for line in channels_logos:
        if not line.strip():
            continue
        name, url = line.split(',')
        if name == channel_name:
            return url
    return None

# 将TXT文件转换为M3U格式的函数
def make_m3u(txt_file, m3u_file):
    try:
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        lines = input_text.strip().split("\n")
        group_name = ""
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url=get_logo_by_channel_name(channel_name)
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1  tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\"  group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)

        print(f"▶️ M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"发生错误: {e}")

# 生成M3U文件
make_m3u(OUTPUT_FULL, OUTPUT_FULL.replace(".txt", ".m3u"))
make_m3u(OUTPUT_LITE, OUTPUT_LITE.replace(".txt", ".m3u"))
make_m3u(OUTPUT_CUSTOM, OUTPUT_CUSTOM.replace(".txt", ".m3u"))

print("📊 生成统计信息")
# 计算脚本执行时间
timeend = get_beijing_time()
elapsed_time = timeend - timestart
total_seconds = elapsed_time.total_seconds()
minutes = int(total_seconds // 60)
seconds = int(total_seconds % 60)

# 格式化时间字符串
timestart_str = timestart.strftime("%Y%m%d %H:%M:%S")
timeend_str = timeend.strftime("%Y%m%d %H:%M:%S")

print(f"开始时间: {timestart_str}")
print(f"结束时间: {timeend_str}")
print(f"执行时间: {minutes} 分 {seconds} 秒")

# ========= 新增：去重统计信息 =========
processed_urls_count = len(processed_urls)  # 处理的唯一URL数
blacklist_urls_count = len(combined_blacklist)  # 黑名单URL数
total_processed_urls = processed_urls_count + blacklist_urls_count  # 总处理URL数

print(f"📊 去重统计信息:")
print(f"   处理的唯一URL数: {processed_urls_count}")
print(f"   黑名单URL数: {blacklist_urls_count}")
print(f"   总处理URL数: {total_processed_urls}")
if total_processed_urls > 0:
    duplication_rate = (1 - processed_urls_count / total_processed_urls) * 100
    print(f"   🔄 去重率: {duplication_rate:.1f}%")
else:
    print(f"   🔄 去重率: N/A")

# 统计信息
combined_blacklist_hj = len(combined_blacklist)
all_lines_full_hj = len(all_lines_full)
other_lines_hj = len(other_lines)
print(f"黑名单行数: {combined_blacklist_hj} ")
print(f"完整版行数: {all_lines_full_hj} ")
print(f"其它源行数: {other_lines_hj} ")

print("✅ 处理完成!")

# ====== 直播源聚合处理工具 v2.03 ======